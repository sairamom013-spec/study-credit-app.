const btn = document.getElementById("musicToggle");

const tracks = [

  { audio: bg1, fx: startHearts },

  { audio: bg2, fx: startPetals },

  { audio: bg3, fx: startAuroraBubbles },

  { audio: bg4, fx: startSakura }
  

];

let currentIndex = 0;        // kaunsa song next hai

let isPlaying = false;       // abhi music chal raha hai ya nahi

let currentAudio = null;

let stopFx = null;

btn.addEventListener("click", () => {

  // 👉 CASE 1: Music chal raha hai → STOP

  if (isPlaying) {

    if (currentAudio) {

      currentAudio.pause();

      currentAudio.currentTime = 0;

    }

    if (stopFx) stopFx();

    btn.classList.remove("playing");

    isPlaying = false;

    return; // ⛔ yahin ruk jao

  }

  // 👉 CASE 2: Music band hai → NEXT music PLAY

  const track = tracks[currentIndex];

  currentAudio = track.audio;

  currentAudio.volume = 0.99;

  currentAudio.play().catch(() => {});

  stopFx = track.fx();

  btn.classList.add("playing");

  isPlaying = true;

  // 🔁 next time ke liye index badhao

  currentIndex = (currentIndex + 1) % tracks.length;

});


function startHearts() {

  const box = document.getElementById("fx-hearts");

  const i = setInterval(() => {

    const h = document.createElement("div");

    h.className = "heart";

    h.style.left = Math.random()*100+"vw";

    box.appendChild(h);

    setTimeout(()=>h.remove(),7000);

  },500);

  return ()=>{ clearInterval(i); box.innerHTML=""; };

}

function startPetals() {

  const box = document.getElementById("fx-petals");

  const i = setInterval(() => {

    const p = document.createElement("div");

    p.className = "petal";

    p.style.left = Math.random()*100+"vw";

    box.appendChild(p);

    setTimeout(()=>p.remove(),8000);

  },400);

  return ()=>{ clearInterval(i); box.innerHTML=""; };

}

document.getElementById("romanticGlow").classList.add("active");

// stop pe

document.getElementById("romanticGlow").classList.remove("active");






document.getElementById("progressBar").style.width = "10%";




function startAuroraBubbles() {

  const box = document.getElementById("fx-bubbles");

  const glow = document.getElementById("auroraGlow");

 

  const i = setInterval(() => {

    const b = document.createElement("div");

    b.className = "aurora-bubble";

    b.style.left = Math.random() * 100 + "vw";

    box.appendChild(b);

    setTimeout(() => b.remove(), 12000);

  }, 800);

  return () => {

    clearInterval(i);

    box.innerHTML = "";

    

  };

}



function startSakura() {

  const box = document.getElementById("sakuraScene");

  box.classList.add("active");

  const interval = setInterval(() => {

    const p = document.createElement("div");

    p.className = "sakura";

    p.style.left = Math.random() * 100 + "vw";

    p.style.animationDuration = 8 + Math.random() * 6 + "s";

    p.style.transform = `rotate(${Math.random()*360}deg)`;

    box.appendChild(p);

    setTimeout(() => p.remove(), 15000);

  }, 350);

  return () => {

    clearInterval(interval);

    box.innerHTML = "";

    box.classList.remove("active");

  };

}






























































let totalTime = 30 * 60; // 30 minutes in seconds

let timerInterval;


window.addEventListener("load", () => {

  const h1 = document.getElementById("mainHeading");

  if (h1) {

    setTimeout(() => {

      h1.classList.add("animate");

    }, 200);

  }

});


document.getElementById("mainHeading").classList.add("animate");





let questionStartTime = 0;

let timeSpent = [];







function analyzeTest(questions, userAnswers) {
  let score = 0;
  let correct = 0;
  let wrong = 0;
  let skipped = 0;

  let subjectStats = {};
  let chapterStats = {};

  questions.forEach((q, i) => {
    const userAns = userAnswers[i];

    // init subject
    if (!subjectStats[q.subject]) {
      subjectStats[q.subject] = { correct: 0, wrong: 0, skipped: 0 };
    }

    // init chapter
    const chapterKey = q.subject + " :: " + q.chapter;
    if (!chapterStats[chapterKey]) {
      chapterStats[chapterKey] = { correct: 0, wrong: 0, skipped: 0 };
    }

    if (userAns === null || userAns === undefined) {
      skipped++;
      subjectStats[q.subject].skipped++;
      chapterStats[chapterKey].skipped++;
    } 
    else if (userAns === q.ans) {
      score += 4;
      correct++;
      subjectStats[q.subject].correct++;
      chapterStats[chapterKey].correct++;
    } 
    else {
      score -= 1;
      wrong++;
      subjectStats[q.subject].wrong++;
      chapterStats[chapterKey].wrong++;
    }
  });

  const accuracy = correct / (correct + wrong || 1) * 100;

  return {
    score,
    correct,
    wrong,
    skipped,
    accuracy: accuracy.toFixed(2),
    subjectStats,
    chapterStats,
    verdict: getVerdict(accuracy)
  };
}



function getVerdict(acc) {
  if (acc >= 85) return "wow!! You maked mee wett🤤";
  if (acc >= 70) return "aaahh cutie Not bad h😉";
  if (acc >= 55) return "Stamina hee nahi hai, hehe 😏";
  return "💀 Reality Check Zone";
}




function chapterInsights(chapterStats) {

  let strong = [];

  let weak = [];

  for (let ch in chapterStats) {

    const { correct, wrong } = chapterStats[ch];

    const total = correct + wrong;

    if (total >= 3) {

      const acc = correct / total * 100;

      if (acc >= 70) strong.push(ch);

      else if (acc < 40) weak.push(ch);

    }

  }

  return { strong, weak };

}


function getChapterStats() {

  const stats = {};

  shuffledQuestions.forEach((q, i) => {

    if (!stats[q.chapter]) {

      stats[q.chapter] = { correct: 0, wrong: 0 };

    }

    if (userAnswers[i] === q.ans) stats[q.chapter].correct++;

    else if (userAnswers[i] !== undefined) stats[q.chapter].wrong++;

  });

  return stats;

}





function submitTest() {
  closeConfirm();
  clearInterval(timerInterval);

  let correct = 0;
  let wrong = 0;
  let skipped = 0;

  shuffledQuestions.forEach((q, i) => {
    if (userAnswers[i] === undefined) skipped++;
    else if (userAnswers[i] === q.ans) correct++;
    else wrong++;
  });

  const score = correct * 4 - wrong;
  const accuracy = ((correct / (correct + wrong || 1)) * 100).toFixed(2);

  // 🔹 chapter stats
  const resultChapterStats = getChapterStats();

  // 🔹 result object (PEHLE BANAO)
  const result = {
    score,
    correct,
    wrong,
    skipped,
    accuracy,
    chapterStats: resultChapterStats
  };

  // 🔹 hide quiz / show result
  document.getElementById("quiz-section").style.display = "none";
  document.getElementById("resultScreen").style.display = "block";

  document.getElementById("finalScore").innerText = `Score: ${score}`;
  document.getElementById("correctCount").innerText = `✅ Correct: ${correct}`;
  document.getElementById("wrongCount").innerText = `❌ Wrong: ${wrong}`;
  document.getElementById("skippedCount").innerText = `⚠️ Skipped: ${skipped}`;
  document.getElementById("accuracy").innerText = `🎯 Accuracy: ${accuracy}%`;

  // 🔥 SMART SUGGESTIONS (AB SAFE)
  const smartTips = generateSmartSuggestions(result, result.chapterStats);

  const list = document.getElementById("suggestions");
  list.innerHTML = "";

  smartTips.forEach(tip => {
    const li = document.createElement("li");
    li.innerText = tip;
    list.appendChild(li);
  });

  // 🔹 history save
  saveTestHistory(score, accuracy);
  loadHistory();

  console.log(result); // debug
}

function getChapterStats() {

  const stats = {};

  shuffledQuestions.forEach((q, i) => {

    if (!stats[q.chapter]) {

      stats[q.chapter] = { correct: 0, wrong: 0 };

    }

    if (userAnswers[i] === q.ans) stats[q.chapter].correct++;

    else if (userAnswers[i] !== undefined) stats[q.chapter].wrong++;

  });

  return stats;
  

}




function autoSubmitTest() {
  // hide submit button
  document.getElementById("submitBtn").style.display = "none";

  // optional info message
  document.getElementById("info").innerText =
    "⏰ Time up! Test auto-submitted.";

  // direct submit (NO confirmation)
  submitTest();
}




function generateSmartSuggestions(result, chapterStats) {
  let suggestions = [];

  // Accuracy vs Attempts
  if (result.accuracy < 60 && result.correct + result.wrong > 20) {
    suggestions.push(
      "⚠️ You are attempting too many questions with low accuracy. Slow down and focus on correctness."
    );
  }

  if (result.accuracy > 75 && result.correct + result.wrong < 20) {
    suggestions.push(
      "🚀 Good accuracy but low attempts. Increase your speed."
    );
  }

  // Time analysis
  const avgTime =
    timeSpent.reduce((a, b) => a + b, 0) / (timeSpent.length || 1);

  if (avgTime > 90) {
    suggestions.push(
      "⏳ You are spending too much time per question. Practice timed tests."
    );
  }

  // Weak chapters
  for (let ch in chapterStats) {
    const { correct, wrong } = chapterStats[ch];
    if (wrong >= 3) {
      suggestions.push(`📘 Revise chapter: ${ch}`);
    }
  }

  return suggestions;
}













function startRandomTest() {

  // existing code...

  currentQuestion = 0;

  score = 0;

  userAnswers = [];

  shuffledQuestions = shuffle([...questions]).slice(0, 30);

  document.getElementById("quiz-section").style.display = "none";

  // 👉 ADD THIS LINE

  document.getElementById("submitBtn").style.display = "inline-block";

  loadQuestion();

  startTimer(30 * 60);

}














/* ===== MASTER QUESTION BANK ===== */
/* 👉 Yahin sab subjects + chapters ke questions add karte jao */

let testQuestions = [];
let currentQ = 0;
let score = 0;

/* ===== START TEST ===== */
function startTest() {
  if (questionBank.length < 30) {
    alert("⚠️ Please add at least 30 questions in questionBank");
    return;
  }
  
  

  
  
  
  
  
 clearInterval(timerInterval);

totalTime = 30 * 60;

startTimer();

  score = 0;
  currentQ = 0;

  testQuestions = shuffle([...questionBank]).slice(0, 30);
  loadQuestion();
}

/* ===== LOAD QUESTION ===== */
function loadQuestion() {
  let q = testQuestions[currentQ];

  document.getElementById("info").innerText =
    `Q${currentQ + 1}/30 | ${q.subject} – ${q.chapter}`;

  document.getElementById("question").innerText = q.q;
  document.getElementById("progress").innerText =
    `Score: ${score}`;

  const optionsDiv = document.getElementById("options");
  optionsDiv.innerHTML = "";

  q.options.forEach((opt, i) => {
    let btn = document.createElement("button");
    btn.innerText = opt;
    btn.onclick = () => checkAnswer(i);
    optionsDiv.appendChild(btn);
  });
}

/* ===== CHECK ANSWER ===== */
function checkAnswer(selected) {

  if (selected === testQuestions[currentQ].ans) {

    score += 1;        // correct

  } else {

    score -= 0.25;     // negative marking

  }

  currentQ++;

  if (currentQ < 30) {

    loadQuestion();

  } else {

    endTest();

  }

}



function endTest() {

  clearInterval(timerInterval);
  
  exitFullScreen();

  document.getElementById("info").innerText = "";

  document.getElementById("options").innerHTML = "";

  document.getElementById("timer").innerText = "⏱️ Test Over";

  document.getElementById("question").innerText =

    `🎉 Test Finished!\nFinal Score: ${score.toFixed(2)} / 30`;

}



function shuffle(array) {

  for (let i = array.length - 1; i > 0; i--) {

    let j = Math.floor(Math.random() * (i + 1));

    [array[i], array[j]] = [array[j], array[i]];

  }

  return array;

}




























/* ===== LOAD QUESTION ===== */

  function vibrateOption(type = "tap") {
  if (!navigator.vibrate) return;

  if (type === "tap") navigator.vibrate(20);
  if (type === "correct") navigator.vibrate([40, 20, 40]);
  if (type === "wrong") navigator.vibrate([100, 40, 100]);
}
  
  
  
  
  
  
function startTimer() {
  timerInterval = setInterval(() => {
    let min = Math.floor(totalTime / 60);
    let sec = totalTime % 60;

    document.getElementById("timer").innerText =
      `⏱️ Time Left: ${min}:${sec < 10 ? "0" : ""}${sec}`;

    totalTime--;

    if (totalTime < 0) {
      clearInterval(timerInterval);
      endTest();
    }
  }, 1000);
}

  
  






function confirmSubmit() {
  document.getElementById("confirmModal").style.display = "flex";
}

function closeConfirm() {
  document.getElementById("confirmModal").style.display = "none";
}






function enterFullScreen() {

  const elem = document.documentElement;

  if (elem.requestFullscreen) elem.requestFullscreen();

  else if (elem.webkitRequestFullscreen) elem.webkitRequestFullscreen();

  else if (elem.msRequestFullscreen) elem.msRequestFullscreen();

}

function exitFullScreen() {

  if (document.exitFullscreen) document.exitFullscreen();

}

function todayDate() {

  return new Date().toISOString().split("T")[0];

}



 
  





  
  


const questionBank = [ 

  
  
 
  // ===== BIOLOGY =====
  {
    subject: "Biology",
    chapter: "Human Reproduction",
    q: "Site of fertilization in humans is:",
    options: ["Ovary", "Uterus", "Fallopian tube", "Cervix"],
    ans: 2
  },
  {
    subject: "Biology",
    chapter: "Molecular Basis of Inheritance",
    q: "Which enzyme is responsible for DNA replication?",
    options: ["RNA polymerase", "DNA polymerase", "Ligase", "Helicase"],
    ans: 1
  },
  {
    subject: "Biology",
    chapter: "Human Health and Disease",
    q: "Which cells are involved in humoral immunity?",
    options: ["T-cells", "B-cells", "NK cells", "Macrophages"],
    ans: 1
  },

  // ===== PHYSICS =====
  {
    subject: "Physics",
    chapter: "Ray Optics",
    q: "Power of a convex lens is positive because:",
    options: [
      "It diverges light",
      "It converges light",
      "Focal length is infinite",
      "Image is always virtual"
    ],
    ans: 1
  },
  {
    subject: "Physics",
    chapter: "Electrostatics",
    q: "SI unit of electric field is:",
    options: ["Volt", "Volt/meter", "Newton", "Coulomb"],
    ans: 1
  },
  {
    subject: "Physics",
    chapter: "Dual Nature of Radiation",
    q: "Threshold frequency depends on:",
    options: ["Intensity of light", "Material of surface", "Distance", "Area"],
    ans: 1
  },
    
  // ===== BIOLOGY : Molecular Basis of Inheritance =====

{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Which enzyme removes RNA primers during DNA replication in prokaryotes?",
  options: ["DNA ligase", "DNA polymerase I", "DNA polymerase III", "RNA polymerase"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "The direction of DNA synthesis is always:",
  options: ["3′ → 5′", "5′ → 3′", "Both directions", "Random"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Okazaki fragments are formed on which strand?",
  options: ["Leading strand", "Lagging strand", "Template strand", "Coding strand"],
  ans: 1 
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Which bond is broken by helicase during DNA replication?",
  options: ["Phosphodiester bond", "Hydrogen bond", "Glycosidic bond", "Peptide bond"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Sigma factor in prokaryotes is required for:",
  options: ["Elongation", "Termination", "Initiation", "Proofreading"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "AUG codon codes for:",
  options: ["Valine", "Methionine", "Glycine", "Stop signal"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Which RNA carries amino acids to the ribosome?",
  options: ["mRNA", "rRNA", "tRNA", "snRNA"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Lac operon is an example of:",
  options: ["Constitutive operon", "Repressible operon", "Inducible operon", "Feedback operon"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "In lac operon, repressor binds to:",
  options: ["Promoter", "Operator", "Structural gene", "Regulator gene"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Which mutation causes frameshift?",
  options: ["Substitution", "Inversion", "Deletion of one base", "Duplication"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Which experiment proved DNA as genetic material?",
  options: ["Griffith", "Hershey–Chase", "Meselson–Stahl", "Miller–Urey"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Which enzyme charges tRNA with amino acid?",
  options: ["RNA polymerase", "Peptidyl transferase", "Aminoacyl-tRNA synthetase", "Ligase"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Which codon does not code for any amino acid?",
  options: ["UAA", "UGG", "AUG", "UAC"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Peptide bond formation during translation is catalyzed by:",
  options: ["Protein enzyme", "mRNA", "tRNA", "rRNA"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Central dogma of molecular biology was proposed by:",
  options: ["Watson", "Crick", "Chargaff", "Franklin"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Which enzyme joins Okazaki fragments?",
  options: ["DNA polymerase I", "DNA polymerase III", "DNA ligase", "Primase"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Anticodon is present on:",
  options: ["mRNA", "rRNA", "tRNA", "DNA"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Which RNA forms the structural part of ribosome?",
  options: ["mRNA", "tRNA", "rRNA", "snRNA"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Which process converts DNA information into RNA?",
  options: ["Translation", "Replication", "Transcription", "Reverse transcription"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Molecular Basis of Inheritance",
  q: "Which base is absent in RNA?",
  options: ["Adenine", "Uracil", "Thymine", "Guanine"],
  ans: 2
}  ,
    
    // ===== BIOLOGY : Principles of Inheritance & Variation =====

{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Mendel selected pea plant because it has:",
  options: ["Long life cycle", "Bisexual flowers", "Self pollination", "All of these"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Law of segregation is based on which generation?",
  options: ["P", "F1", "F2", "Test cross"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Phenotypic ratio in a monohybrid cross is:",
  options: ["1:2:1", "3:1", "9:3:3:1", "1:1"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Genotypic ratio in a monohybrid cross is:",
  options: ["3:1", "1:1", "1:2:1", "9:3:3:1"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "A test cross is performed with:",
  options: ["Homozygous dominant", "Heterozygous", "Homozygous recessive", "F1 hybrid"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Dihybrid cross phenotypic ratio is:",
  options: ["3:1", "1:2:1", "9:3:3:1", "1:1:1:1"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Incomplete dominance was observed in:",
  options: ["Pea plant", "Mirabilis jalapa", "Drosophila", "Maize"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "In incomplete dominance, F2 phenotypic ratio is:",
  options: ["3:1", "1:2:1", "9:3:3:1", "1:1"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "AB blood group is an example of:",
  options: ["Incomplete dominance", "Dominance", "Codominance", "Epistasis"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Which chromosome determines sex in humans?",
  options: ["X chromosome", "Y chromosome", "Autosome", "Both X and Y"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Haemophilia is a:",
  options: ["Autosomal recessive disorder", "Autosomal dominant disorder", "X-linked recessive disorder", "Y-linked disorder"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Colour blindness is inherited as:",
  options: ["Autosomal dominant", "Autosomal recessive", "X-linked recessive", "Y-linked"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Down syndrome is caused by:",
  options: ["Deletion", "Translocation", "Trisomy 21", "Monosomy"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "A male having genotype XXY suffers from:",
  options: ["Turner syndrome", "Klinefelter syndrome", "Down syndrome", "Edward syndrome"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Crossing over occurs during:",
  options: ["Prophase I", "Metaphase I", "Anaphase I", "Telophase I"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Linkage was first discovered by:",
  options: ["Mendel", "Morgan", "Watson", "Crick"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Genes located on same chromosome are called:",
  options: ["Alleles", "Linked genes", "Homologous genes", "Independent genes"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Recombination frequency is measured in:",
  options: ["Centimorgan", "Angstrom", "Nanometer", "Micron"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Which type of cross gives 1:1 ratio?",
  options: ["Monohybrid cross", "Dihybrid cross", "Test cross", "Back cross"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Multiple alleles are best represented by:",
  options: ["Rh factor", "ABO blood group", "Skin colour", "Height"],
  ans: 1
},
 
   // ===== PHYSICS : Ray Optics & Optical Instruments =====

{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "A ray of light passes from air to glass. Which quantity remains unchanged?",
  options: ["Speed", "Wavelength", "Frequency", "Velocity"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "The refractive index of a medium is maximum when the speed of light is:",
  options: ["Maximum", "Minimum", "Equal to vacuum", "Zero"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "Total internal reflection occurs when light travels from:",
  options: ["Rarer to denser medium", "Denser to rarer medium", "Vacuum to glass", "Glass to vacuum only"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "Critical angle depends on:",
  options: ["Angle of incidence", "Wavelength only", "Refractive indices of two media", "Thickness of medium"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "Which of the following works on total internal reflection?",
  options: ["Simple microscope", "Telescope", "Optical fibre", "Convex lens"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "For a convex lens, focal length is taken as:",
  options: ["Negative", "Zero", "Positive", "Infinite"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "Power of a lens is measured in:",
  options: ["Meter", "Dioptre", "Watt", "Tesla"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "If focal length of a lens is 50 cm, its power is:",
  options: ["+1 D", "+2 D", "+0.5 D", "+5 D"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "A real and inverted image is formed by:",
  options: ["Concave lens", "Convex lens only", "Plane mirror", "Concave mirror only"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "Magnification produced by a plane mirror is:",
  options: ["Less than 1", "Greater than 1", "Equal to 1", "Zero"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "The focal length of a concave mirror is:",
  options: ["Positive", "Negative", "Zero", "Infinite"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "Which mirror is used as a rear-view mirror in vehicles?",
  options: ["Plane mirror", "Concave mirror", "Convex mirror", "Parabolic mirror"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "Myopia can be corrected using:",
  options: ["Convex lens", "Concave lens", "Cylindrical lens", "Bifocal lens"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "Hypermetropia is due to:",
  options: ["Short eyeball", "Long eyeball", "High power lens", "Low power cornea"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "Which instrument is used to observe distant objects clearly?",
  options: ["Microscope", "Simple microscope", "Telescope", "Periscope"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "Angular magnification of an astronomical telescope in normal adjustment is:",
  options: ["fo/fe", "fe/fo", "fo + fe", "fo − fe"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "In refraction through a prism, deviation depends on:",
  options: ["Angle of prism", "Wavelength of light", "Refractive index", "All of these"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "Dispersion occurs because refractive index depends on:",
  options: ["Speed", "Frequency", "Wavelength", "Amplitude"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "Which colour deviates most in a prism?",
  options: ["Red", "Yellow", "Green", "Violet"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Ray Optics",
  q: "The phenomenon responsible for formation of rainbow is:",
  options: ["Reflection only", "Refraction only", "Dispersion and total internal reflection", "Diffraction"],
  ans: 2
},
    
   
    
    // ===== CHEMISTRY : Electrochemistry =====

{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "The SI unit of electrical conductivity is:",
  options: ["Ohm", "Ohm cm", "S m⁻¹", "S cm⁻¹"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Conductance of a solution depends on:",
  options: ["Nature of electrolyte only", "Concentration only", "Temperature only", "All of these"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Specific conductance is the conductance of:",
  options: ["1 cm length", "1 cm³ solution", "1 mole solution", "Infinite dilution"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Molar conductivity increases with dilution because:",
  options: [
    "Number of ions increases",
    "Mobility of ions increases",
    "Electrolyte decomposes",
    "Viscosity increases"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "At infinite dilution, molar conductivity of strong electrolyte:",
  options: ["Becomes zero", "Becomes constant", "Decreases", "Becomes maximum"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Kohlrausch’s law is used to determine:",
  options: [
    "Conductivity of weak electrolyte",
    "Degree of dissociation",
    "Molar conductivity at infinite dilution",
    "All of these"
  ],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "The unit of molar conductivity is:",
  options: ["S m⁻¹", "S cm² mol⁻¹", "Ohm m", "Ohm⁻¹"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "In galvanic cell, oxidation occurs at:",
  options: ["Cathode", "Anode", "Salt bridge", "Electrolyte"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "EMF of a cell is maximum when:",
  options: ["Cell is short-circuited", "Current flows", "No current flows", "Resistance is zero"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Standard electrode potential is measured with respect to:",
  options: [
    "Calomel electrode",
    "Standard hydrogen electrode",
    "Glass electrode",
    "Metal electrode"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Which electrode has zero standard potential?",
  options: ["Zn/Zn²⁺", "Cu/Cu²⁺", "H⁺/H₂", "Ag/Ag⁺"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "In Daniell cell, the cathode is:",
  options: ["Zinc rod", "Copper rod", "Salt bridge", "Electrolyte"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Positive value of E°cell indicates:",
  options: [
    "Non-spontaneous reaction",
    "Spontaneous reaction",
    "Equilibrium",
    "Zero free energy change"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Relation between ΔG° and E°cell is:",
  options: [
    "ΔG° = nFE°",
    "ΔG° = −nFE°",
    "ΔG° = −FE°",
    "ΔG° = nF/E°"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "During electrolysis, oxidation takes place at:",
  options: ["Cathode", "Anode", "Both electrodes", "Neither"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Faraday’s first law relates mass deposited to:",
  options: ["Voltage", "Current", "Charge passed", "Resistance"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "One faraday of electricity is equal to:",
  options: [
    "96500 C",
    "9650 C",
    "9.65 C",
    "965000 C"
  ],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Which battery is rechargeable?",
  options: ["Dry cell", "Mercury cell", "Lead storage battery", "Fuel cell"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "In lead storage battery, the electrolyte used is:",
  options: ["HCl", "HNO₃", "H₂SO₄", "NaOH"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Corrosion of iron is an example of:",
  options: [
    "Electrolytic corrosion",
    "Chemical corrosion",
    "Electrochemical corrosion",
    "Dry corrosion"
  ],
  ans: 2
},
    
   

{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "The central metal atom in a coordination compound is a:",
  options: ["Lewis acid", "Lewis base", "Brønsted acid", "Brønsted base"],
  ans: 0
},
  
  
  
  
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "The coordination number of cobalt in [Co(NH3)6]Cl3 is:",
  options: ["3", "4", "6", "9"],
  ans: 2
},

  {
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which ligand is bidentate?",
  options: ["NH3", "H2O", "C2O4^2−", "Cl−"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "The oxidation state of Fe in [Fe(CN)6]4− is:",
  options: ["+2", "+3", "+4", "0"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which of the following is an ambidentate ligand?",
  options: ["NH3", "H2O", "SCN−", "OH−"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which complex shows geometrical isomerism?",
  options: ["[Co(NH3)6]3+", "[Pt(NH3)2Cl2]", "[Ni(CO)4]", "[Fe(CN)6]3−"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "The IUPAC name of [Cr(H2O)6]Cl3 is:",
  options: [
    "Chromium hexaaqua trichloride",
    "Hexaaquachromium(III) chloride",
    "Hexachlorochromium(III)",
    "Chromium(III) chloride hexahydrate"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which theory explains the magnetic properties of coordination compounds?",
  options: [
    "Valence bond theory",
    "Crystal field theory",
    "Molecular orbital theory",
    "Hybridization theory"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Strong field ligands cause pairing of electrons because they:",
  options: [
    "Decrease Δo",
    "Increase Δo",
    "Reduce oxidation state",
    "Increase coordination number"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which of the following is a strong field ligand?",
  options: ["F−", "Cl−", "H2O", "CN−"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "The complex [Ni(CO)4] is:",
  options: ["Paramagnetic", "Diamagnetic", "Tetrahedral ionic", "Square planar"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which complex is expected to be paramagnetic?",
  options: ["[Fe(CN)6]4−", "[Ni(CO)4]", "[CoF6]3−", "[Zn(NH3)4]2+"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Werner’s theory explains:",
  options: [
    "Isomerism only",
    "Bonding only",
    "Primary and secondary valencies",
    "Magnetic behaviour only"
  ],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which of the following exhibits optical isomerism?",
  options: [
    "[Co(NH3)6]3+",
    "[Pt(NH3)2Cl2]",
    "[Cr(C2O4)3]3−",
    "[Ni(CO)4]"
  ],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Chelation increases stability because it:",
  options: [
    "Decreases entropy",
    "Increases entropy",
    "Decreases enthalpy only",
    "Increases oxidation state"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "The coordination geometry of [Cu(NH3)4]2+ is:",
  options: ["Tetrahedral", "Square planar", "Octahedral", "Linear"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which ligand donates electrons through nitrogen atom?",
  options: ["CN−", "NO2−", "NH3", "SCN−"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "The effective atomic number (EAN) of Ni in [Ni(CO)4] is:",
  options: ["26", "28", "36", "54"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which of the following is a neutral ligand?",
  options: ["CN−", "OH−", "NH3", "Cl−"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "The colour of coordination compounds is due to:",
  options: [
    "Charge transfer",
    "d–d transitions",
    "s–p transitions",
    "Ligand vibrations"
  ],
  ans: 1
},
    
  // ===== PHYSICS : Electrostatics =====

{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "SI unit of electric charge is:",
  options: ["Ampere", "Coulomb", "Volt", "Farad"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "Coulomb’s law is applicable to:",
  options: ["Moving charges", "Stationary point charges", "Current carrying conductors", "Magnetic poles"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "The force between two charges becomes four times when the distance between them is:",
  options: ["Doubled", "Halved", "Tripled", "Quadrupled"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "Electric field intensity at a point is defined as:",
  options: [
    "Force per unit charge",
    "Charge per unit force",
    "Energy per unit charge",
    "Work per unit distance"
  ],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "SI unit of electric field is:",
  options: ["N/C", "V", "C/N", "J/C"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "Electric field inside a conductor in electrostatic equilibrium is:",
  options: ["Maximum", "Minimum", "Zero", "Infinite"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "Electric potential is a:",
  options: ["Scalar quantity", "Vector quantity", "Tensor quantity", "Dimensionless quantity"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "SI unit of electric potential is:",
  options: ["Joule", "Coulomb", "Volt", "Ampere"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "Relation between electric field (E) and potential (V) is:",
  options: ["E = dV/dx", "E = −dV/dx", "V = dE/dx", "E = V/d"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "Equipotential surfaces are always:",
  options: ["Parallel to electric field", "Perpendicular to electric field", "Circular", "Elliptical"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "Work done in moving a charge along an equipotential surface is:",
  options: ["Maximum", "Minimum", "Zero", "Infinite"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "Capacitance depends on:",
  options: ["Charge", "Potential", "Geometry of conductor", "Current"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "SI unit of capacitance is:",
  options: ["Farad", "Henry", "Ohm", "Tesla"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "Capacitance of a parallel plate capacitor increases when:",
  options: [
    "Distance between plates increases",
    "Area of plates decreases",
    "Dielectric is introduced",
    "Charge is increased"
  ],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "Energy stored in a capacitor is given by:",
  options: ["½ CV²", "CV²", "QV", "Q²/C"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "Dielectric constant of a medium is equal to:",
  options: ["ε₀/ε", "ε/ε₀", "1/ε₀", "ε₀ε"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "Gauss’s law is useful for calculating electric field when charge distribution is:",
  options: ["Irregular", "Random", "Highly symmetric", "Discrete"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "Electric flux through a closed surface depends on:",
  options: [
    "Charge enclosed",
    "Shape of surface",
    "Area of surface",
    "Electric field outside"
  ],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "The electric field due to an infinite plane sheet of charge is:",
  options: ["Zero", "Depends on distance", "Constant", "Infinite"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Electrostatics",
  q: "The potential at the center of a charged spherical shell is:",
  options: ["Zero", "Maximum", "Same as surface potential", "Infinite"],
  ans: 2
},  
    
  // ===== PHYSICS : Current Electricity =====

{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "SI unit of electric current is:",
  options: ["Volt", "Ampere", "Ohm", "Coulomb"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "Drift velocity of electrons in a conductor is:",
  options: ["Very large", "Comparable to speed of light", "Very small", "Zero"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "Ohm’s law is valid when:",
  options: [
    "Temperature is constant",
    "Potential is zero",
    "Resistance is zero",
    "Current is alternating"
  ],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "Resistance of a conductor depends on:",
  options: ["Length", "Area of cross-section", "Material", "All of these"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "SI unit of resistivity is:",
  options: ["Ohm", "Ohm m", "Ohm m⁻¹", "Ohm m²"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "Which material has negative temperature coefficient of resistance?",
  options: ["Copper", "Iron", "Germanium", "Aluminium"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "If length of a wire is doubled, its resistance becomes:",
  options: ["Half", "Double", "Four times", "Same"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "If radius of a wire is doubled, its resistance becomes:",
  options: ["Double", "Half", "One-fourth", "Four times"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "Equivalent resistance of two equal resistors R in parallel is:",
  options: ["R", "2R", "R/2", "R/4"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "Equivalent resistance of two equal resistors R in series is:",
  options: ["R", "2R", "R/2", "R/4"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "Electrical energy consumed is measured in:",
  options: ["Watt", "Joule", "Kilowatt-hour", "Ampere"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "Electrical power is given by:",
  options: ["VI", "V/I", "I/V", "R/I"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "Unit of electrical power is:",
  options: ["Joule", "Watt", "Volt", "Ampere"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "Kirchhoff’s first law is based on conservation of:",
  options: ["Energy", "Charge", "Momentum", "Mass"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "Kirchhoff’s second law is based on conservation of:",
  options: ["Charge", "Energy", "Current", "Resistance"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "EMF of a cell is defined as:",
  options: [
    "Potential difference across terminals when current flows",
    "Energy supplied per unit charge",
    "Charge supplied per unit energy",
    "Resistance of the cell"
  ],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "Internal resistance of a cell depends on:",
  options: [
    "Distance between electrodes",
    "Area of electrodes",
    "Nature of electrolyte",
    "All of these"
  ],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "Terminal voltage of a cell is less than EMF when:",
  options: [
    "Cell is open",
    "No current flows",
    "Current is drawn from cell",
    "Internal resistance is zero"
  ],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "Maximum power is delivered to a load when:",
  options: [
    "Load resistance is zero",
    "Load resistance is infinite",
    "Load resistance equals internal resistance",
    "Load resistance is greater than internal resistance"
  ],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Current Electricity",
  q: "Heating effect of electric current is explained by:",
  options: ["Faraday’s law", "Ohm’s law", "Joule’s law", "Kirchhoff’s law"],
  ans: 2
},
    
    // ===== BIOLOGY : Human Reproduction (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Spermatogenesis occurs in which part of testis?",
  options: ["Seminiferous tubules", "Vasa efferentia", "Epididymis", "Interstitial space"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which cells secrete testosterone?",
  options: ["Sertoli cells", "Leydig cells", "Germ cells", "Spermatogonia"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which hormone is responsible for ovulation?",
  options: ["FSH", "LH", "Estrogen", "Progesterone"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Fertilization in humans normally occurs in:",
  options: ["Ovary", "Uterus", "Cervix", "Ampullary-isthmic junction"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Zona pellucida is a layer present around:",
  options: ["Sperm", "Ovum", "Zygote", "Embryo"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Implantation of embryo occurs in:",
  options: ["Fallopian tube", "Ovary", "Uterus", "Cervix"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Human gestation period is approximately:",
  options: ["180 days", "240 days", "270 days", "300 days"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which hormone maintains pregnancy?",
  options: ["Estrogen", "FSH", "LH", "Progesterone"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which structure connects fetus to placenta?",
  options: ["Amnion", "Chorion", "Umbilical cord", "Yolk sac"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which hormone is detected in pregnancy test kits?",
  options: ["LH", "FSH", "hCG", "Progesterone"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which stage of embryo is implanted in uterus?",
  options: ["Zygote", "Morula", "Blastocyst", "Gastrula"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Parturition is controlled by:",
  options: ["Only oxytocin", "Only estrogen", "Neuroendocrine mechanism", "FSH and LH"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which membrane surrounds the fetus?",
  options: ["Chorion", "Amnion", "Allantois", "Yolk sac"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Colostrum is rich in:",
  options: ["Fats", "Proteins", "Antibodies", "Vitamins"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which process forms haploid gametes?",
  options: ["Mitosis", "Meiosis", "Fertilization", "Cleavage"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which structure prevents polyspermy?",
  options: ["Corona radiata", "Zona pellucida", "Vitelline membrane", "Amnion"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "FSH in males acts on:",
  options: ["Leydig cells", "Sertoli cells", "Prostate gland", "Seminal vesicles"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which hormone initiates milk secretion?",
  options: ["Oxytocin", "Prolactin", "Estrogen", "Progesterone"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which stage is formed after morula?",
  options: ["Zygote", "Gastrula", "Blastula", "Neurula"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Menstrual cycle is regulated by hormones from:",
  options: ["Only ovary", "Only pituitary", "Ovary and pituitary", "Hypothalamus only"],
  ans: 2
},
    
  // ===== BIOLOGY : Biotechnology – Principles & Processes (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Which enzyme is used to cut DNA at specific palindromic sequences?",
  options: ["DNA ligase", "Restriction endonuclease", "DNA polymerase", "RNA polymerase"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "The enzyme used to join DNA fragments is:",
  options: ["Primase", "Ligase", "Helicase", "Topoisomerase"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Plasmids are commonly used as vectors because they:",
  options: ["Are linear DNA", "Replicate independently", "Have ribosomes", "Lack origin of replication"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "The origin of replication (ori) is essential for:",
  options: ["Protein synthesis", "Transcription", "Initiation of replication", "Translation"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Selectable marker genes help in:",
  options: ["Replication of DNA", "Identifying transformed cells", "Cutting DNA", "Ligation"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Which antibiotic resistance gene is commonly used as a selectable marker?",
  options: ["Insulin", "LacZ", "Ampicillin resistance", "Trypsin"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Blue-white screening is based on inactivation of:",
  options: ["ampR gene", "tetR gene", "lacZ gene", "ori"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Which organism is most commonly used for gene cloning?",
  options: ["Yeast", "E. coli", "Virus", "Algae"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "PCR was developed by:",
  options: ["Watson", "Crick", "Kary Mullis", "Paul Berg"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Which enzyme is used in PCR?",
  options: ["DNA polymerase I", "RNA polymerase", "Taq DNA polymerase", "Ligase"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Denaturation step in PCR involves:",
  options: ["Primer binding", "DNA synthesis", "Separation of DNA strands", "Ligation"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Annealing in PCR refers to:",
  options: ["DNA synthesis", "Primer binding to template", "Strand separation", "Cooling of enzyme"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Extension step in PCR occurs at approximately:",
  options: ["37°C", "50°C", "72°C", "95°C"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Which technique separates DNA fragments based on size?",
  options: ["Chromatography", "Centrifugation", "Gel electrophoresis", "Spectrophotometry"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Ethidium bromide is used in gel electrophoresis to:",
  options: ["Cut DNA", "Ligate DNA", "Stain DNA", "Amplify DNA"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Which method is used to introduce recombinant DNA into host cells?",
  options: ["Hybridization", "Transformation", "Translation", "Replication"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Microinjection involves direct injection of DNA into:",
  options: ["Cytoplasm", "Nucleus", "Cell wall", "Vacuole"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Bioreactors are used for:",
  options: ["Gene cutting", "Gene ligation", "Large-scale production of products", "DNA sequencing"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Stirred-tank bioreactors are preferred because they provide:",
  options: ["Low oxygen", "No mixing", "Optimal growth conditions", "No temperature control"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Downstream processing refers to:",
  options: ["Gene cloning", "Fermentation", "Purification of product", "PCR amplification"],
  ans: 2
},
    
   // ===== BIOLOGY : Biotechnology – Applications (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "The first recombinant human insulin was produced using:",
  options: ["Yeast", "E. coli", "Virus", "Algae"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Insulin produced by recombinant DNA technology is called:",
  options: ["Humulin", "Proinsulin", "Somatotropin", "Interferon"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Which cells are used to produce monoclonal antibodies?",
  options: ["Hybridoma cells", "Stem cells", "Myeloma cells", "Lymphocytes"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Gene therapy involves:",
  options: [
    "Replacement of defective gene",
    "Removal of chromosome",
    "Protein therapy",
    "Vaccination"
  ],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "First successful gene therapy was done for:",
  options: ["Cancer", "ADA deficiency", "Diabetes", "Thalassemia"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Bt cotton is resistant to insects because it produces:",
  options: ["Antibiotic", "Cry protein", "Interferon", "Insulin"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Cry proteins are produced by:",
  options: ["E. coli", "Agrobacterium", "Bacillus thuringiensis", "Rhizobium"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "RNA interference (RNAi) is used to:",
  options: [
    "Increase gene expression",
    "Silence specific genes",
    "Repair DNA",
    "Translate mRNA"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Golden rice is genetically modified to produce:",
  options: ["Vitamin C", "Vitamin A", "Vitamin D", "Vitamin B12"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Transgenic animals are those which:",
  options: [
    "Have foreign gene inserted",
    "Are cloned animals",
    "Are hybrids",
    "Have mutations only"
  ],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Which transgenic animal is used to study cancer?",
  options: ["Cow", "Sheep", "Mouse", "Goat"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Biotechnology helps in producing vaccines that are:",
  options: ["Live attenuated", "Killed", "Subunit vaccines", "Toxoid vaccines"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Edible vaccines are produced in:",
  options: ["Animals", "Bacteria", "Plants", "Viruses"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Bioremediation refers to:",
  options: [
    "Use of chemicals to clean environment",
    "Use of microbes to clean pollutants",
    "Physical removal of waste",
    "Radiation treatment"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Which organism is used in sewage treatment?",
  options: ["Virus", "Protozoa", "Bacteria", "Algae only"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "GM crops are mainly developed for:",
  options: [
    "Higher yield",
    "Insect resistance",
    "Stress tolerance",
    "All of these"
  ],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Which protein is used as a molecular marker?",
  options: ["Insulin", "GFP", "Hemoglobin", "Trypsin"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Biosafety issues are related to:",
  options: [
    "Human health only",
    "Environment only",
    "Ethical issues only",
    "Health, environment and ethics"
  ],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Which committee regulates GM crops in India?",
  options: ["WHO", "GEAC", "ICMR", "FAO"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Applications",
  q: "Biopatent is related to:",
  options: [
    "Ownership of living organisms or products",
    "Environmental protection",
    "Gene therapy",
    "Cloning"
  ],
  ans: 0
},
    
  
    // ===== BIOLOGY : Ecology & Environment (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "The functional unit of ecosystem is:",
  options: ["Population", "Community", "Ecosystem", "Biome"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "Primary producers in an ecosystem are:",
  options: ["Herbivores", "Carnivores", "Green plants", "Decomposers"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "Which pyramid is always upright?",
  options: ["Pyramid of biomass", "Pyramid of number", "Pyramid of energy", "All pyramids"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "10% law of energy transfer was proposed by:",
  options: ["Lindeman", "Darwin", "Odum", "Elton"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "Decomposers mainly belong to:",
  options: ["Producers", "Herbivores", "Carnivores", "Bacteria and fungi"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "Standing crop refers to:",
  options: [
    "Energy in ecosystem",
    "Biomass at a given time",
    "Population density",
    "Rate of production"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "Which of the following is a density–dependent factor?",
  options: ["Flood", "Earthquake", "Competition", "Drought"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "The logistic growth curve is represented by:",
  options: ["J-shaped curve", "S-shaped curve", "Exponential curve", "Linear curve"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "Carrying capacity of an environment is denoted by:",
  options: ["r", "N", "K", "λ"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "Which interaction benefits one species and harms the other?",
  options: ["Mutualism", "Commensalism", "Parasitism", "Amensalism"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "Lichens represent which type of interaction?",
  options: ["Parasitism", "Mutualism", "Commensalism", "Predation"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "Which biome has the highest biodiversity?",
  options: ["Desert", "Grassland", "Tundra", "Tropical rainforest"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "Ozone layer depletion is mainly caused by:",
  options: ["CO₂", "SO₂", "CFCs", "NO₂"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "The Kyoto Protocol is related to control of:",
  options: ["Ozone depletion", "Global warming", "Acid rain", "Water pollution"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "Biodiversity hotspots are regions with:",
  options: [
    "High species richness only",
    "High endemism and threat",
    "Low biodiversity",
    "Only endangered species"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "Which gas is mainly responsible for global warming?",
  options: ["Oxygen", "Nitrogen", "Carbon dioxide", "Helium"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "Ex-situ conservation includes:",
  options: ["Wildlife sanctuary", "National park", "Zoo", "Biosphere reserve"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "The term biodiversity was popularised by:",
  options: ["Darwin", "E.O. Wilson", "Odum", "Mayr"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "Which of the following causes biomagnification?",
  options: ["CO₂", "Plastics", "Heavy metals", "Nitrogen"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecology & Environment",
  q: "Sacred groves are an example of:",
  options: ["In-situ conservation", "Ex-situ conservation", "Gene bank", "Cryopreservation"],
  ans: 0
},
    
    
  // ===== BIOLOGY : Human Health & Disease (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which cells are primarily involved in humoral immunity?",
  options: ["T-helper cells", "Cytotoxic T cells", "B cells", "NK cells"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Antibodies are chemically:",
  options: ["Lipids", "Carbohydrates", "Glycoproteins", "Nucleic acids"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which immunoglobulin is most abundant in blood plasma?",
  options: ["IgA", "IgE", "IgG", "IgM"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Memory cells are formed during:",
  options: ["Innate immunity", "Primary immune response", "Secondary immune response", "Passive immunity"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which of the following provides passive immunity to the fetus?",
  options: ["IgA", "IgE", "IgG", "IgM"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which vaccine provides immunity by using weakened pathogens?",
  options: ["Killed vaccine", "Subunit vaccine", "Live attenuated vaccine", "Toxoid"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "AIDS is caused by a virus that primarily infects:",
  options: ["B cells", "Macrophages", "Helper T cells", "NK cells"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "The causative organism of malaria is:",
  options: ["Entamoeba", "Trypanosoma", "Plasmodium", "Leishmania"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which stage of Plasmodium infects human liver cells?",
  options: ["Merozoite", "Sporozoite", "Gametocyte", "Ookinete"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which disease is caused by Trypanosoma gambiense?",
  options: ["Kala-azar", "Sleeping sickness", "Malaria", "Amoebiasis"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which pathogen causes amoebiasis?",
  options: ["Entamoeba histolytica", "Giardia lamblia", "Ascaris lumbricoides", "Taenia solium"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which of the following is a bacterial disease?",
  options: ["Malaria", "Typhoid", "AIDS", "Influenza"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which diagnostic test is used to detect HIV infection?",
  options: ["Widal test", "ELISA", "PCR only", "Mantoux test"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Interferons are secreted by virus-infected cells to:",
  options: [
    "Kill bacteria",
    "Prevent viral replication in neighbouring cells",
    "Increase RBC count",
    "Activate antibodies directly"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which cancer-causing agents are present in tobacco smoke?",
  options: ["Antibiotics", "Carcinogens", "Hormones", "Antibodies"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which of the following is NOT a mode of HIV transmission?",
  options: ["Unprotected sex", "Sharing needles", "Mosquito bite", "Blood transfusion"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Autoimmune diseases occur when:",
  options: [
    "Immune system attacks pathogens",
    "Immune system attacks own cells",
    "Immunity is absent",
    "Only antibodies are produced"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which disorder is caused due to deficiency of insulin?",
  options: ["Diabetes mellitus", "Goitre", "Addison’s disease", "Cushing’s syndrome"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which drug is commonly abused as a depressant?",
  options: ["Caffeine", "Nicotine", "Alcohol", "Amphetamine"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which organ is most affected by chronic alcoholism?",
  options: ["Kidney", "Heart", "Liver", "Lungs"],
  ans: 2
},  
    
    // ===== BIOLOGY : Reproductive Health (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Reproductive health refers to:",
  options: [
    "Absence of disease only",
    "Physical health only",
    "Mental health only",
    "Total well-being in reproductive aspects"
  ],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which method of contraception prevents implantation?",
  options: ["Condom", "Copper-T", "Oral pills", "Diaphragm"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Oral contraceptive pills mainly inhibit:",
  options: ["Menstruation", "Ovulation", "Fertilization", "Implantation"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which hormone is present in oral contraceptive pills?",
  options: ["FSH only", "LH only", "Progesterone or progesterone-estrogen", "Testosterone"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which contraceptive method also protects against STDs?",
  options: ["IUD", "Oral pills", "Condom", "Spermicides"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Medical termination of pregnancy (MTP) is safe up to:",
  options: ["6 weeks", "12 weeks", "20 weeks", "28 weeks"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Amniocentesis is legally banned because it was misused for:",
  options: [
    "Detection of genetic disorders",
    "Determination of fetal sex",
    "Studying fetal growth",
    "Detection of chromosomal anomalies"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which disease is a sexually transmitted disease?",
  options: ["Typhoid", "Gonorrhoea", "Malaria", "Tuberculosis"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which STD is caused by a virus?",
  options: ["Syphilis", "Gonorrhoea", "Genital herpes", "Chlamydia"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which method involves cutting and tying vas deferens?",
  options: ["Tubectomy", "Vasectomy", "Hysterectomy", "Laparoscopy"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Tubectomy is a method of contraception in:",
  options: ["Male", "Female", "Both male and female", "Infants"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which assisted reproductive technique involves transfer of embryo to uterus?",
  options: ["GIFT", "ZIFT", "IVF-ET", "AI"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "In ZIFT, the zygote is transferred into:",
  options: ["Uterus", "Cervix", "Fallopian tube", "Ovary"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which technique involves transfer of gametes into fallopian tube?",
  options: ["IVF", "ZIFT", "GIFT", "ICSI"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "ICSI is used mainly in case of:",
  options: [
    "Female infertility",
    "Hormonal imbalance",
    "Low sperm count or motility",
    "Blocked oviduct"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which hormone is used in fertility treatment to stimulate ovulation?",
  options: ["Progesterone", "FSH", "Testosterone", "Melatonin"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which barrier method is used by females?",
  options: ["Condom", "Diaphragm", "Copper-T", "Oral pill"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which contraceptive method is irreversible?",
  options: ["Condom", "IUD", "Oral pills", "Sterilization"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which of the following is a natural method of contraception?",
  options: [
    "Copper-T",
    "Withdrawal method",
    "Oral pills",
    "Diaphragm"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Population explosion can be controlled mainly by:",
  options: [
    "Improving food supply",
    "Increasing birth rate",
    "Education and awareness",
    "Improving medical care only"
  ],
  ans: 2
},
    
    // ===== BIOLOGY : Evolution (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Evolution",
  q: "The theory of natural selection was proposed by:",
  options: ["Lamarck", "Darwin", "Hugo de Vries", "Wallace"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "According to Darwin, evolution occurs due to:",
  options: ["Inheritance of acquired characters", "Mutation only", "Natural selection", "Sudden large changes"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which concept explains sudden appearance of new species?",
  options: ["Gradualism", "Natural selection", "Mutation theory", "Genetic drift"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Homologous organs indicate:",
  options: ["Same function, different origin", "Different function, same origin", "Same function and origin", "No relation"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Analogous organs indicate:",
  options: ["Common ancestry", "Divergent evolution", "Convergent evolution", "Adaptive radiation"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Adaptive radiation is best seen in:",
  options: ["Darwin’s finches", "Industrial melanism", "Peppered moth", "Giraffe neck"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which fossil is considered a connecting link between reptiles and birds?",
  options: ["Seymouria", "Archaeopteryx", "Ichthyosaurus", "Dimetrodon"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Industrial melanism was studied in:",
  options: ["Butterfly", "Peppered moth", "Housefly", "Beetle"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "The appearance of long-necked giraffe was explained by Lamarck using:",
  options: ["Natural selection", "Use and disuse", "Mutation", "Isolation"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Hardy–Weinberg principle is related to:",
  options: ["Speciation", "Population genetics", "Mutation", "Isolation"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which of the following does NOT disturb Hardy–Weinberg equilibrium?",
  options: ["Gene flow", "Mutation", "Random mating", "Genetic drift"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Founder effect is a type of:",
  options: ["Gene flow", "Natural selection", "Genetic drift", "Mutation"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which isolating mechanism prevents mating between species?",
  options: ["Geographical isolation", "Behavioral isolation", "Temporal isolation", "All of these"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Speciation due to geographical isolation is called:",
  options: ["Sympatric", "Parapatric", "Allopatric", "Peripatric"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which era is known as the age of reptiles?",
  options: ["Paleozoic", "Mesozoic", "Cenozoic", "Precambrian"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Modern humans belong to:",
  options: ["Homo habilis", "Homo erectus", "Homo sapiens", "Homo neanderthalensis"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "The most accepted theory of origin of life is:",
  options: ["Special creation", "Spontaneous generation", "Biochemical evolution", "Panspermia"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Oparin–Haldane theory is related to:",
  options: ["Natural selection", "Origin of life", "Speciation", "Human evolution"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Miller–Urey experiment demonstrated formation of:",
  options: ["Proteins", "Carbohydrates", "Amino acids", "Nucleic acids"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which gas was NOT used in Miller’s experiment?",
  options: ["Methane", "Ammonia", "Hydrogen", "Oxygen"],
  ans: 3
},
    
  // ===== BIOLOGY : Evolution (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Evolution",
  q: "The theory of natural selection was proposed by:",
  options: ["Lamarck", "Darwin", "Hugo de Vries", "Wallace"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "According to Darwin, evolution occurs due to:",
  options: ["Inheritance of acquired characters", "Mutation only", "Natural selection", "Sudden large changes"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which concept explains sudden appearance of new species?",
  options: ["Gradualism", "Natural selection", "Mutation theory", "Genetic drift"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Homologous organs indicate:",
  options: ["Same function, different origin", "Different function, same origin", "Same function and origin", "No relation"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Analogous organs indicate:",
  options: ["Common ancestry", "Divergent evolution", "Convergent evolution", "Adaptive radiation"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Adaptive radiation is best seen in:",
  options: ["Darwin’s finches", "Industrial melanism", "Peppered moth", "Giraffe neck"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which fossil is considered a connecting link between reptiles and birds?",
  options: ["Seymouria", "Archaeopteryx", "Ichthyosaurus", "Dimetrodon"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Industrial melanism was studied in:",
  options: ["Butterfly", "Peppered moth", "Housefly", "Beetle"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "The appearance of long-necked giraffe was explained by Lamarck using:",
  options: ["Natural selection", "Use and disuse", "Mutation", "Isolation"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Hardy–Weinberg principle is related to:",
  options: ["Speciation", "Population genetics", "Mutation", "Isolation"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which of the following does NOT disturb Hardy–Weinberg equilibrium?",
  options: ["Gene flow", "Mutation", "Random mating", "Genetic drift"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Founder effect is a type of:",
  options: ["Gene flow", "Natural selection", "Genetic drift", "Mutation"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which isolating mechanism prevents mating between species?",
  options: ["Geographical isolation", "Behavioral isolation", "Temporal isolation", "All of these"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Speciation due to geographical isolation is called:",
  options: ["Sympatric", "Parapatric", "Allopatric", "Peripatric"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which era is known as the age of reptiles?",
  options: ["Paleozoic", "Mesozoic", "Cenozoic", "Precambrian"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Modern humans belong to:",
  options: ["Homo habilis", "Homo erectus", "Homo sapiens", "Homo neanderthalensis"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "The most accepted theory of origin of life is:",
  options: ["Special creation", "Spontaneous generation", "Biochemical evolution", "Panspermia"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Oparin–Haldane theory is related to:",
  options: ["Natural selection", "Origin of life", "Speciation", "Human evolution"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Miller–Urey experiment demonstrated formation of:",
  options: ["Proteins", "Carbohydrates", "Amino acids", "Nucleic acids"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which gas was NOT used in Miller’s experiment?",
  options: ["Methane", "Ammonia", "Hydrogen", "Oxygen"],
  ans: 3
},
   
    
    // ===== BIOLOGY : Sexual Reproduction in Flowering Plants (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "The functional megaspore in angiosperms develops into:",
  options: ["Embryo", "Endosperm", "Female gametophyte", "Zygote"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "Microsporogenesis results in the formation of:",
  options: ["Pollen grains", "Ovules", "Embryo sac", "Zygote"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "The outermost layer of pollen grain is called:",
  options: ["Intine", "Exine", "Tapetum", "Sporoderm"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "Exine is composed of a highly resistant substance called:",
  options: ["Cellulose", "Pectin", "Sporopollenin", "Cutin"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "Tapetum provides nourishment to:",
  options: ["Ovules", "Embryo sac", "Developing pollen grains", "Zygote"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "The embryo sac in angiosperms is typically:",
  options: ["4-celled", "7-celled, 8-nucleate", "8-celled", "Multinucleate"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "Which cell of embryo sac develops into endosperm after fertilization?",
  options: ["Egg cell", "Synergid", "Antipodal cell", "Central cell"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "Double fertilization is unique to:",
  options: ["Gymnosperms", "Pteridophytes", "Angiosperms", "Bryophytes"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "Which nucleus fuses with male gamete to form primary endosperm nucleus?",
  options: ["Egg nucleus", "Polar nuclei", "Synergid nucleus", "Antipodal nucleus"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "The transfer of pollen grains from anther to stigma is called:",
  options: ["Fertilization", "Germination", "Pollination", "Syngamy"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "Cleistogamous flowers ensure:",
  options: ["Cross-pollination", "Self-pollination", "Wind pollination", "Insect pollination"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "Which agent is responsible for pollination in Vallisneria?",
  options: ["Wind", "Water", "Insects", "Birds"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "Which plant shows hydrophily?",
  options: ["Sunflower", "Vallisneria", "Pea", "Maize"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "After fertilization, ovary develops into:",
  options: ["Seed", "Fruit", "Embryo", "Endosperm"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "The edible part of coconut is:",
  options: ["Endosperm", "Embryo", "Perisperm", "Cotyledon"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "Polyembryony refers to:",
  options: [
    "Many ovules in one ovary",
    "Many embryos in one seed",
    "Many seeds in one fruit",
    "Many flowers in one inflorescence"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "Apomixis results in seeds that are:",
  options: ["Genetically variable", "Genetically identical to parent", "Haploid", "Sterile"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "Which structure guides pollen tube growth?",
  options: ["Antipodal cells", "Synergids", "Integuments", "Nucellus"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "Endosperm development that occurs in most angiosperms is:",
  options: ["Helobial", "Nuclear", "Cellular", "Free-nuclear only"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Sexual Reproduction in Flowering Plants",
  q: "Perisperm is a remnant of:",
  options: ["Endosperm", "Nucellus", "Integument", "Embryo sac"],
  ans: 1
},
    
  // ===== CHEMISTRY : Amines (HARD NEET) =====

{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Amines are derivatives of:",
  options: ["Ammonia", "Alcohol", "Carboxylic acid", "Aldehyde"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Which amine is a secondary amine?",
  options: ["CH3NH2", "(CH3)2NH", "(CH3)3N", "NH3"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Basicity of amines in aqueous solution depends on:",
  options: [
    "Inductive effect",
    "Solvation effect",
    "Steric hindrance",
    "All of these"
  ],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Which amine is most basic in aqueous solution?",
  options: ["NH3", "CH3NH2", "(CH3)2NH", "(CH3)3N"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Aniline is less basic than methylamine because of:",
  options: [
    "Inductive effect",
    "Resonance effect",
    "Steric effect",
    "Hydrogen bonding"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Which reagent is used to distinguish primary, secondary and tertiary amines?",
  options: ["Fehling solution", "Tollen’s reagent", "Hinsberg reagent", "Lucas reagent"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Primary aliphatic amines on treatment with nitrous acid give:",
  options: ["Alcohol", "Alkene", "Diazonium salt", "Phenol"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Aromatic primary amines react with nitrous acid at 0–5°C to form:",
  options: ["Alcohol", "Phenol", "Diazonium salt", "Aniline"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Benzene diazonium chloride is prepared by reacting aniline with:",
  options: [
    "NaNO2 + HCl at 0–5°C",
    "NaNO3 + HCl",
    "HNO3 alone",
    "NH4Cl"
  ],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Which reaction is used to prepare amines from alkyl halides?",
  options: ["Wurtz reaction", "Gabriel phthalimide synthesis", "Kolbe reaction", "Reimer–Tiemann reaction"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Which amine does not give carbylamine test?",
  options: ["Primary amine", "Secondary amine", "Aromatic primary amine", "Aliphatic primary amine"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Carbylamine test is given by amines having:",
  options: ["–NH2 group", "–NH group", "–N group", "No N–H bond"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Aniline reacts with bromine water to form:",
  options: ["Bromobenzene", "p-Bromoaniline", "2,4,6-Tribromoaniline", "m-Bromoaniline"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Which group is introduced by diazotization followed by coupling?",
  options: ["–NO2", "–N=N–", "–NH2", "–OH"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Aniline is acetylated to protect which group?",
  options: ["Phenyl ring", "Amino group", "Methyl group", "Hydroxyl group"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Which amine is used in the manufacture of dyes?",
  options: ["Methylamine", "Ethylamine", "Aniline", "Dimethylamine"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Hoffmann bromamide reaction converts amide into:",
  options: ["Amine with same carbon number", "Amine with one less carbon", "Amine with one more carbon", "Nitrile"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Which compound is the weakest base?",
  options: ["Ammonia", "Methylamine", "Aniline", "Dimethylamine"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Which amine will be most soluble in water?",
  options: ["Aniline", "Ethylamine", "Diphenylamine", "Triphenylamine"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Amines",
  q: "Diazonium salts are generally stable at:",
  options: ["Room temperature", "High temperature", "0–5°C", "Below −20°C"],
  ans: 2
},
    
    // ===== CHEMISTRY : Biomolecules (HARD NEET) =====

{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Glucose and fructose are examples of:",
  options: ["Disaccharides", "Polysaccharides", "Monosaccharides", "Oligosaccharides"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Which carbohydrate is known as milk sugar?",
  options: ["Sucrose", "Glucose", "Lactose", "Maltose"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Which of the following is a non-reducing sugar?",
  options: ["Glucose", "Fructose", "Lactose", "Sucrose"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Starch is a polymer of:",
  options: ["α-glucose", "β-glucose", "Fructose", "Galactose"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Cellulose is composed of:",
  options: ["α-glucose units", "β-glucose units", "Fructose units", "Sucrose units"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Which linkage is present in proteins?",
  options: ["Glycosidic bond", "Peptide bond", "Hydrogen bond", "Phosphodiester bond"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Proteins are polymers of:",
  options: ["Fatty acids", "Amino acids", "Nucleotides", "Sugars"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Which level of protein structure is stabilized by hydrogen bonds?",
  options: ["Primary", "Secondary", "Tertiary", "Quaternary"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Denaturation of proteins results in loss of:",
  options: ["Primary structure", "Secondary structure", "Tertiary structure", "All structures"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Which vitamin is water soluble?",
  options: ["Vitamin A", "Vitamin D", "Vitamin E", "Vitamin C"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Deficiency of vitamin C causes:",
  options: ["Rickets", "Scurvy", "Beriberi", "Night blindness"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Which vitamin deficiency causes night blindness?",
  options: ["Vitamin A", "Vitamin B1", "Vitamin C", "Vitamin D"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "DNA differs from RNA in having:",
  options: ["Ribose sugar", "Uracil base", "Deoxyribose sugar", "Single strand"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "The base present in RNA but absent in DNA is:",
  options: ["Thymine", "Adenine", "Uracil", "Cytosine"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Nucleoside is composed of:",
  options: ["Base + sugar", "Base + phosphate", "Sugar + phosphate", "Base + sugar + phosphate"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Nucleotide differs from nucleoside by the presence of:",
  options: ["Sugar", "Nitrogen base", "Phosphate group", "Hydrogen bond"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Which hormone is a peptide hormone?",
  options: ["Insulin", "Testosterone", "Estrogen", "Adrenaline"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Enzymes are chemically:",
  options: ["Lipids", "Carbohydrates", "Proteins", "Nucleic acids"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Which polysaccharide is stored in animal body?",
  options: ["Starch", "Cellulose", "Glycogen", "Chitin"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Biomolecules",
  q: "Chitin is a polymer of:",
  options: ["Glucose", "Fructose", "N-acetyl glucosamine", "Galactose"],
  ans: 2
},
    
    
    // ===== CHEMISTRY : Aldehydes, Ketones & Carboxylic Acids (HARD NEET) =====

{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Which functional group is present in aldehydes?",
  options: ["–COOH", "–CHO", "–CO–", "–OH"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Which compound gives positive Tollens’ test?",
  options: ["Acetone", "Benzophenone", "Acetaldehyde", "Acetophenone"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Which reagent distinguishes aldehydes from ketones?",
  options: ["Fehling’s solution", "Benedict’s solution", "Tollens’ reagent", "All of these"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Fehling’s solution is reduced by:",
  options: ["All aldehydes", "Aromatic aldehydes only", "Aliphatic aldehydes", "Ketones"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Which compound gives iodoform test?",
  options: ["Methanol", "Acetaldehyde", "Formaldehyde", "Formic acid"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "The product formed when aldehydes are reduced is:",
  options: ["Acid", "Ester", "Alcohol", "Ketone"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Which reagent is used for reduction of aldehydes and ketones?",
  options: ["KMnO4", "K2Cr2O7", "NaBH4", "HNO3"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Which acid is strongest among the following?",
  options: ["Formic acid", "Acetic acid", "Propionic acid", "Butyric acid"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Carboxylic acids show acidic character due to:",
  options: ["Resonance stabilization of conjugate base", "Inductive effect only", "Hydrogen bonding", "Large size"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Which carboxylic acid is present in vinegar?",
  options: ["Formic acid", "Acetic acid", "Citric acid", "Lactic acid"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Decarboxylation of sodium salts of acids with soda lime gives:",
  options: ["Alcohol", "Alkene", "Alkane", "Aldehyde"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Which compound does NOT give silver mirror test?",
  options: ["Formaldehyde", "Acetaldehyde", "Acetone", "Glucose"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Cannizzaro reaction is shown by aldehydes:",
  options: ["With α-hydrogen", "Without α-hydrogen", "Only aromatic", "Only aliphatic"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Aldol condensation occurs in aldehydes having:",
  options: ["No hydrogen", "α-hydrogen", "Only aromatic ring", "Carboxyl group"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Which compound undergoes Cannizzaro reaction?",
  options: ["Acetaldehyde", "Formaldehyde", "Propanal", "Butanal"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Which acid is used as a food preservative?",
  options: ["Benzoic acid", "Oxalic acid", "Formic acid", "Tartaric acid"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Which compound is oxidized to give aldehyde?",
  options: ["Primary alcohol", "Secondary alcohol", "Tertiary alcohol", "Phenol"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Which reagent oxidizes aldehydes but not ketones?",
  options: ["KMnO4", "K2Cr2O7", "Tollens’ reagent", "HNO3"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "The –COOH group is known as:",
  options: ["Carbonyl group", "Carboxyl group", "Hydroxyl group", "Aldehyde group"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Aldehydes, Ketones & Carboxylic Acids",
  q: "Which compound is a ketone?",
  options: ["Propanal", "Ethanol", "Propanone", "Ethanoic acid"],
  ans: 2
},
    
  // ===== PHYSICS : Magnetism & Matter (HARD NEET) =====

{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "SI unit of magnetic field is:",
  options: ["Weber", "Tesla", "Ampere", "Henry"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Magnetic field lines always form:",
  options: ["Straight lines", "Closed loops", "Open curves", "Parallel lines"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Which of the following is a vector quantity?",
  options: ["Magnetic flux", "Magnetic moment", "Magnetic susceptibility", "Permeability"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "The SI unit of magnetic dipole moment is:",
  options: ["A m", "A m²", "T m", "Wb m"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Earth’s magnetic field at the equator is:",
  options: ["Maximum", "Minimum", "Zero", "Infinite"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Angle between geographic meridian and magnetic meridian is called:",
  options: ["Dip", "Inclination", "Declination", "Latitude"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Angle between Earth’s magnetic field and horizontal plane is called:",
  options: ["Declination", "Dip", "Azimuth", "Latitude"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "At magnetic equator, angle of dip is:",
  options: ["0°", "45°", "90°", "180°"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "At magnetic poles, angle of dip is:",
  options: ["0°", "45°", "60°", "90°"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Which material is strongly attracted by a magnetic field?",
  options: ["Diamagnetic", "Paramagnetic", "Ferromagnetic", "Non-magnetic"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Magnetic susceptibility of diamagnetic substances is:",
  options: ["Positive and large", "Positive and small", "Negative and small", "Zero"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Which of the following is diamagnetic?",
  options: ["Iron", "Cobalt", "Nickel", "Copper"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Curie temperature is the temperature above which a ferromagnetic material becomes:",
  options: ["Diamagnetic", "Paramagnetic", "Non-magnetic", "Superconducting"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Which law gives magnetic field due to a current element?",
  options: ["Coulomb’s law", "Faraday’s law", "Ampere’s law", "Biot–Savart law"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Magnetic flux through a closed surface is always:",
  options: ["Maximum", "Minimum", "Zero", "Infinite"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Which instrument is used to measure horizontal component of Earth’s magnetic field?",
  options: ["Ammeter", "Voltmeter", "Tangent galvanometer", "Moving coil galvanometer"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Bar magnet behaves like:",
  options: ["Electric dipole", "Electric monopole", "Current loop", "Solenoid only"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Magnetic field at the center of a circular current-carrying loop depends on:",
  options: ["Current only", "Radius only", "Number of turns only", "All of these"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Permeability of free space (μ₀) has the unit:",
  options: ["T m/A", "N/A²", "Wb/A m", "All of these"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Magnetism & Matter",
  q: "Which quantity remains constant for a given material in magnetization?",
  options: ["Magnetic field", "Magnetization", "Magnetic susceptibility", "Magnetic flux"],
  ans: 2
},
    
    // ===== PHYSICS : Electromagnetic Induction (HARD NEET) =====

{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "Faraday’s first law of electromagnetic induction states that:",
  options: [
    "Induced emf is proportional to current",
    "Induced emf is produced when magnetic flux changes",
    "Magnetic field induces charge",
    "Flux is always conserved"
  ],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "Lenz’s law is a consequence of conservation of:",
  options: ["Charge", "Momentum", "Energy", "Mass"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "The SI unit of magnetic flux is:",
  options: ["Tesla", "Weber", "Henry", "Volt"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "Which factor does NOT affect induced emf?",
  options: [
    "Rate of change of flux",
    "Number of turns",
    "Resistance of the circuit",
    "Magnetic field strength"
  ],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "Self-inductance depends on:",
  options: [
    "Geometry of coil",
    "Number of turns",
    "Nature of core",
    "All of these"
  ],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "SI unit of self-inductance is:",
  options: ["Tesla", "Weber", "Henry", "Ohm"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "Mutual inductance is maximum when coils are:",
  options: [
    "Far apart",
    "At right angles",
    "Closely coupled",
    "Of unequal turns"
  ],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "Eddy currents are produced due to:",
  options: [
    "Static magnetic field",
    "Changing magnetic field",
    "Electric field",
    "Gravitational field"
  ],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "Eddy current losses are minimized by:",
  options: [
    "Using thick metal plates",
    "Using laminated cores",
    "Using copper core",
    "Increasing magnetic field"
  ],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "Which device works on electromagnetic induction?",
  options: ["Transformer", "Electric heater", "Battery", "Galvanometer"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "In a transformer, the core is laminated to reduce:",
  options: ["Hysteresis loss", "Eddy current loss", "Flux leakage", "Resistance"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "A step-up transformer increases:",
  options: ["Current", "Voltage", "Power", "Frequency"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "Transformer works only on:",
  options: ["DC", "AC", "Both AC and DC", "Pulsed DC"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "Back emf in a motor is produced due to:",
  options: [
    "Ohm’s law",
    "Faraday’s law",
    "Lenz’s law",
    "Joule heating"
  ],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "The direction of induced current is given by:",
  options: [
    "Fleming’s right hand rule",
    "Fleming’s left hand rule",
    "Maxwell’s rule",
    "Ampere’s rule"
  ],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "The magnitude of induced emf is maximum when:",
  options: [
    "Flux is constant",
    "Flux changes slowly",
    "Flux changes rapidly",
    "Flux is zero"
  ],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "Which phenomenon explains damping in a moving coil galvanometer?",
  options: [
    "Hysteresis",
    "Eddy currents",
    "Self induction",
    "Mutual induction"
  ],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "Energy stored in an inductor is:",
  options: [
    "½ LI²",
    "LI²",
    "½ CV²",
    "QV"
  ],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "Which quantity opposes change in current in a circuit?",
  options: ["Resistance", "Capacitance", "Inductance", "Conductance"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Electromagnetic Induction",
  q: "Induced emf is zero when magnetic flux is:",
  options: ["Maximum", "Minimum", "Zero", "Constant"],
  ans: 3
},
    
    
    // ===== PHYSICS : Alternating Current (HARD NEET) =====

{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "The frequency of AC in India is:",
  options: ["50 Hz", "60 Hz", "100 Hz", "25 Hz"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "The rms value of AC current is related to peak value as:",
  options: ["Irms = I0", "Irms = I0/√2", "Irms = √2 I0", "Irms = I0/2"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "Average value of AC over one complete cycle is:",
  options: ["Zero", "Maximum", "Minimum", "Irms"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "In a purely resistive AC circuit, current and voltage are:",
  options: ["Out of phase by 90°", "In phase", "Out of phase by 180°", "Leading by 45°"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "In a purely inductive circuit, current:",
  options: ["Leads voltage by 90°", "Lags voltage by 90°", "Is in phase", "Leads by 45°"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "In a purely capacitive circuit, current:",
  options: ["Lags voltage by 90°", "Leads voltage by 90°", "Is in phase", "Lags by 45°"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "Reactance of an inductor is given by:",
  options: ["XL = ωL", "XL = 1/ωC", "XL = R", "XL = ωC"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "Capacitive reactance decreases when:",
  options: ["Frequency increases", "Frequency decreases", "Capacitance decreases", "Resistance increases"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "Impedance in an AC circuit is the vector sum of:",
  options: ["R and C", "R and L", "Resistance and reactance", "Voltage and current"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "The power factor of an AC circuit is:",
  options: ["sinφ", "cosφ", "tanφ", "cotφ"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "In a purely inductive or capacitive circuit, average power consumed is:",
  options: ["Maximum", "Minimum", "Zero", "Half of maximum"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "Resonance in LCR circuit occurs when:",
  options: ["XL = XC", "XL > XC", "XL < XC", "R = 0"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "At resonance, impedance of LCR series circuit is:",
  options: ["Maximum", "Minimum", "Zero", "Infinite"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "Quality factor (Q) of a resonant circuit measures:",
  options: ["Power loss", "Sharpness of resonance", "Frequency", "Resistance"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "The unit of impedance is:",
  options: ["Ohm", "Henry", "Farad", "Tesla"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "In an LCR circuit, maximum current flows when circuit is at:",
  options: ["High resistance", "Low frequency", "Resonance", "Zero voltage"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "AC voltmeter measures:",
  options: ["Peak value", "Average value", "RMS value", "Instantaneous value"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "Choke coil is used to:",
  options: ["Increase current", "Decrease current without power loss", "Convert AC to DC", "Increase voltage"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "Which device improves power factor?",
  options: ["Inductor", "Resistor", "Capacitor", "Transformer"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Alternating Current",
  q: "The phase difference between voltage and current at resonance is:",
  options: ["0°", "45°", "90°", "180°"],
  ans: 0
},
    
    
    // ===== PHYSICS : Wave Optics (HARD NEET) =====

{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Wave optics is based on which principle?",
  options: ["Newton’s corpuscular theory", "Huygens’ principle", "Einstein’s photoelectric equation", "Snell’s law"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Interference of light is possible only when sources are:",
  options: ["Monochromatic", "Coherent", "Incoherent", "Polarized"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "In Young’s double slit experiment, bright fringes occur due to:",
  options: ["Destructive interference", "Diffraction", "Constructive interference", "Polarization"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Fringe width in YDSE depends on:",
  options: ["Wavelength", "Distance between slits", "Distance of screen", "All of these"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "If wavelength of light is increased, fringe width will:",
  options: ["Decrease", "Remain same", "Increase", "Become zero"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Diffraction becomes prominent when the size of obstacle is:",
  options: ["Much larger than wavelength", "Equal to wavelength", "Much smaller than wavelength", "Infinite"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Single slit diffraction pattern has maximum intensity at:",
  options: ["First minima", "Second minima", "Central maximum", "Side maxima"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Width of central maximum in single slit diffraction is:",
  options: ["λ/a", "2λ/a", "a/λ", "λ/2a"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Polarization of light proves that light is:",
  options: ["Longitudinal wave", "Transverse wave", "Mechanical wave", "Sound wave"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Which waves can be polarized?",
  options: ["Sound waves", "Water waves", "Light waves", "All waves"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Brewster’s law relates refractive index with:",
  options: ["Angle of incidence", "Angle of reflection", "Polarizing angle", "Critical angle"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "At Brewster angle, reflected and refracted rays are:",
  options: ["Parallel", "Perpendicular", "Equal", "Opposite"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Which phenomenon explains colours in thin films?",
  options: ["Diffraction", "Polarization", "Interference", "Scattering"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Optical path difference depends on:",
  options: ["Refractive index", "Geometrical path", "Both", "Neither"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Coherent sources have:",
  options: ["Same amplitude", "Same wavelength", "Constant phase difference", "Same intensity"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Which color has the shortest wavelength?",
  options: ["Red", "Green", "Blue", "Violet"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "In YDSE, if one slit is closed, the pattern observed is:",
  options: ["Interference", "Diffraction", "No pattern", "Polarization"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Resolving power of an optical instrument depends on:",
  options: ["Wavelength of light", "Aperture", "Both", "Neither"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Rayleigh criterion is related to:",
  options: ["Interference", "Diffraction", "Polarization", "Reflection"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Wave Optics",
  q: "Which device uses polarization to reduce glare?",
  options: ["Microscope", "Polarizing sunglasses", "Telescope", "Spectrometer"],
  ans: 1
},
    
    // ===== PHYSICS : Dual Nature of Radiation & Matter (HARD NEET) =====

{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "Photoelectric effect supports the concept of:",
  options: ["Wave nature of light", "Particle nature of light", "Polarization", "Interference"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "The minimum frequency required to eject electrons from a metal surface is called:",
  options: ["Cut-off frequency", "Threshold frequency", "Resonance frequency", "Critical frequency"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "In photoelectric effect, kinetic energy of emitted electrons depends on:",
  options: ["Intensity of light", "Frequency of light", "Time of exposure", "Area of metal"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "Stopping potential in photoelectric effect depends on:",
  options: ["Intensity", "Frequency", "Work function", "Both frequency and work function"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "Work function of a metal is expressed in:",
  options: ["Joule", "eV", "Watt", "Volt"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "Which metal has the lowest work function?",
  options: ["Sodium", "Zinc", "Copper", "Iron"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "Einstein’s photoelectric equation is based on conservation of:",
  options: ["Momentum", "Charge", "Energy", "Mass"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "The particle associated with matter waves was proposed by:",
  options: ["Einstein", "Bohr", "de Broglie", "Planck"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "de Broglie wavelength is inversely proportional to:",
  options: ["Velocity", "Momentum", "Energy", "Mass only"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "de Broglie wavelength of an electron increases when its:",
  options: ["Velocity increases", "Momentum increases", "Velocity decreases", "Energy increases"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "Which particles exhibit wave nature?",
  options: ["Electrons only", "Photons only", "All moving particles", "Charged particles only"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "Davisson–Germer experiment demonstrated:",
  options: ["Photoelectric effect", "Compton effect", "Wave nature of electrons", "Particle nature of light"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "Which radiation has maximum photoelectric effect for a given metal?",
  options: ["Infrared", "Visible", "Ultraviolet", "Microwaves"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "Intensity of incident light in photoelectric effect controls:",
  options: ["Kinetic energy", "Stopping potential", "Number of photoelectrons", "Work function"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "Planck’s constant has the dimension of:",
  options: ["Energy", "Energy × time", "Momentum", "Force × time"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "Which phenomenon cannot be explained by wave theory of light?",
  options: ["Interference", "Diffraction", "Polarization", "Photoelectric effect"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "For a given frequency, stopping potential is independent of:",
  options: ["Intensity", "Metal used", "Frequency", "Work function"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "The photoelectric current is maximum when:",
  options: ["Intensity is maximum", "Frequency is maximum", "Work function is maximum", "Stopping potential is maximum"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "Which particle has the longest de Broglie wavelength at same kinetic energy?",
  options: ["Electron", "Proton", "Neutron", "Alpha particle"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Dual Nature of Radiation & Matter",
  q: "The dual nature of matter becomes significant for objects of:",
  options: ["Macroscopic size", "Microscopic size", "Astronomical size", "Daily life objects"],
  ans: 1
},
    
    // ===== PHYSICS : Atoms & Nuclei (HARD NEET) =====

{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Rutherford’s scattering experiment established that:",
  options: [
    "Atom is a solid sphere",
    "Positive charge is uniformly distributed",
    "Most of the mass is concentrated at the center",
    "Electrons are embedded in nucleus"
  ],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "According to Bohr’s model, angular momentum of electron is:",
  options: ["Continuous", "Zero", "Quantized", "Infinite"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Radius of the nth orbit in hydrogen atom is proportional to:",
  options: ["n", "n²", "1/n", "1/n²"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Energy of electron in nth orbit of hydrogen atom is proportional to:",
  options: ["n", "n²", "1/n", "1/n²"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Which transition in hydrogen atom gives Lyman series?",
  options: ["n → 1", "n → 2", "n → 3", "n → ∞"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Balmer series lies in the:",
  options: ["Infrared region", "Visible region", "Ultraviolet region", "Microwave region"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Which radiation has maximum penetrating power?",
  options: ["Alpha", "Beta", "Gamma", "X-rays"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Alpha particles are:",
  options: ["Electrons", "Photons", "Helium nuclei", "Protons"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Unit of radioactivity is:",
  options: ["Gray", "Sievert", "Becquerel", "Curie"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Half-life of a radioactive substance depends on:",
  options: [
    "Temperature",
    "Pressure",
    "Amount of substance",
    "Nature of nucleus"
  ],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Binding energy of nucleus is due to:",
  options: [
    "Electrostatic force",
    "Gravitational force",
    "Strong nuclear force",
    "Weak nuclear force"
  ],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Mass defect is defined as difference between:",
  options: [
    "Mass of nucleus and mass number",
    "Sum of masses of nucleons and actual mass of nucleus",
    "Mass of atom and mass of electrons",
    "Mass of proton and neutron"
  ],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Binding energy per nucleon is maximum for:",
  options: ["Hydrogen", "Uranium", "Iron", "Carbon"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Nuclear fission occurs in:",
  options: ["Hydrogen bomb", "Atomic bomb", "Sun", "Stars"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Nuclear fusion occurs in:",
  options: ["Atomic bomb", "Nuclear reactor", "Sun", "Radioactive decay"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Energy released in nuclear reactions is calculated using:",
  options: ["E = mc²", "F = ma", "E = hf", "V = IR"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Which particle is emitted during beta decay?",
  options: ["Helium nucleus", "Neutron", "Electron", "Proton"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "In beta decay, atomic number:",
  options: ["Increases by 1", "Decreases by 1", "Remains same", "Becomes zero"],
  ans: 0
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Isotopes have same:",
  options: ["Mass number", "Atomic number", "Neutron number", "Nuclear stability"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Atoms & Nuclei",
  q: "Which quantity is conserved in all nuclear reactions?",
  options: ["Mass", "Energy", "Charge", "Volume"],
  ans: 2
},
    
    // ===== PHYSICS : Semiconductor Electronics (HARD NEET) =====

{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "Intrinsic semiconductors at room temperature have:",
  options: ["Only electrons", "Only holes", "Equal number of electrons and holes", "No charge carriers"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "Which material is an intrinsic semiconductor?",
  options: ["Copper", "Silicon", "Iron", "Aluminium"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "Doping pure silicon with phosphorus produces:",
  options: ["p-type semiconductor", "n-type semiconductor", "Insulator", "Metal"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "Majority charge carriers in p-type semiconductor are:",
  options: ["Electrons", "Protons", "Holes", "Ions"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "Which impurity is used to make p-type semiconductor?",
  options: ["Phosphorus", "Arsenic", "Antimony", "Boron"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "In a p–n junction diode under forward bias:",
  options: ["Depletion layer widens", "Barrier potential increases", "Current flows easily", "No current flows"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "In reverse bias of a p–n junction diode:",
  options: ["Barrier potential decreases", "Depletion layer narrows", "Large current flows", "Very small current flows"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "The depletion region of a p–n junction has:",
  options: ["Free electrons only", "Free holes only", "No free charge carriers", "Ions only"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "Which diode is used as a voltage regulator?",
  options: ["LED", "Photodiode", "Zener diode", "Tunnel diode"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "Zener diode works in:",
  options: ["Forward bias only", "Reverse bias only", "Both biases", "Zero bias"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "LED emits light due to:",
  options: ["Thermal effect", "Recombination of charge carriers", "Photoelectric effect", "Joule heating"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "Which colour LED has maximum energy photons?",
  options: ["Red", "Green", "Yellow", "Blue"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "A photodiode works mainly in:",
  options: ["Forward bias", "Reverse bias", "Zero bias", "Breakdown region"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "In a transistor, the emitter region is:",
  options: ["Lightly doped", "Moderately doped", "Heavily doped", "Undoped"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "The function of a transistor is to:",
  options: ["Rectify AC", "Amplify signals", "Store energy", "Measure voltage"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "Which transistor configuration has highest current gain?",
  options: ["Common base", "Common emitter", "Common collector", "Emitter follower"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "Logic gate that gives HIGH output only when all inputs are HIGH is:",
  options: ["OR gate", "AND gate", "NOT gate", "NAND gate"],
  ans: 1
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "Which logic gate is known as a universal gate?",
  options: ["AND", "OR", "XOR", "NAND"],
  ans: 3
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "Truth table with output always opposite to input represents:",
  options: ["AND gate", "OR gate", "NOT gate", "NOR gate"],
  ans: 2
},
{
  subject: "Physics",
  chapter: "Semiconductor Electronics",
  q: "Integrated circuits (ICs) are fabricated using:",
  options: ["Metals only", "Insulators only", "Semiconductor materials", "Superconductors"],
  ans: 2
},
    
    
    
    // ===== CHEMISTRY : Haloalkanes & Haloarenes (HARD NEET) =====

{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Haloalkanes are also known as:",
  options: ["Alkyl halides", "Aryl halides", "Alcohols", "Amines"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Which bond is most polar in haloalkanes?",
  options: ["C–F", "C–Cl", "C–Br", "C–I"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "SN1 reaction proceeds through formation of:",
  options: ["Free radical", "Carbanion", "Carbocation", "Carbene"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Which haloalkane shows maximum SN1 reactivity?",
  options: ["CH3Cl", "C2H5Cl", "(CH3)2CHCl", "(CH3)3CCl"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "SN2 reaction is favored by:",
  options: ["Tertiary halides", "Secondary halides", "Primary halides", "Aryl halides"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "SN2 reactions are characterized by:",
  options: ["Carbocation formation", "Racemization", "Inversion of configuration", "Rearrangement"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Which solvent favors SN1 reaction?",
  options: ["Non-polar solvent", "Polar protic solvent", "Polar aprotic solvent", "Ether"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Which solvent favors SN2 reaction?",
  options: ["Water", "Alcohol", "DMSO", "Acetic acid"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Aryl halides are less reactive towards nucleophilic substitution because of:",
  options: [
    "Resonance stabilization of C–X bond",
    "Inductive effect",
    "Steric hindrance only",
    "Weak C–X bond"
  ],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Which halide undergoes nucleophilic substitution most easily?",
  options: ["R–F", "R–Cl", "R–Br", "R–I"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Grignard reagent is prepared using:",
  options: ["Dry ether", "Water", "Alcohol", "Aqueous medium"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Which compound reacts fastest with alcoholic KOH?",
  options: ["CH3Cl", "C2H5Cl", "(CH3)2CHCl", "(CH3)3CCl"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Reaction of haloalkanes with KCN gives:",
  options: ["Isocyanides", "Nitriles", "Amines", "Alcohols"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Reaction of haloalkanes with AgCN gives:",
  options: ["Nitriles", "Isocyanides", "Amines", "Nitro compounds"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Which compound is known as freon?",
  options: ["CHCl3", "CCl4", "CF2Cl2", "CH2Cl2"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "DDT is used as:",
  options: ["Fertilizer", "Insecticide", "Herbicide", "Fungicide"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Chlorobenzene reacts with NaOH at high temperature and pressure to form:",
  options: ["Phenol", "Benzyl alcohol", "Aniline", "Toluene"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Which compound is used as an anaesthetic?",
  options: ["Chloroform", "Carbon tetrachloride", "DDT", "Chlorobenzene"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Which reaction is used to convert alcohols to haloalkanes?",
  options: ["Wurtz reaction", "Swarts reaction", "Lucas test", "Finkelstein reaction"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Haloalkanes & Haloarenes",
  q: "Which halide gives positive Beilstein test?",
  options: ["Alcohol", "Amine", "Haloalkane", "Carboxylic acid"],
  ans: 2
},
    
    // ===== CHEMISTRY : Alcohols, Phenols & Ethers (HARD NEET) =====

{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Alcohols are organic compounds containing which functional group?",
  options: ["–COOH", "–CHO", "–OH", "–NH2"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Which alcohol shows maximum intermolecular hydrogen bonding?",
  options: ["Methanol", "Ethanol", "Propanol", "tert-Butanol"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Phenol is more acidic than ethanol due to:",
  options: [
    "Inductive effect",
    "Resonance stabilization of phenoxide ion",
    "Hydrogen bonding",
    "Steric effect"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Which reagent distinguishes phenol from alcohol?",
  options: ["Lucas reagent", "FeCl3", "NaHCO3", "Tollens’ reagent"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Phenol reacts with bromine water to give:",
  options: [
    "Bromobenzene",
    "p-Bromophenol",
    "2,4,6-Tribromophenol",
    "m-Bromophenol"
  ],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Which alcohol reacts fastest with Lucas reagent?",
  options: ["Primary", "Secondary", "Tertiary", "All equally"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Dehydration of alcohols gives:",
  options: ["Alkanes", "Alkenes", "Alkynes", "Aldehydes"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Which reagent is used for dehydration of alcohols?",
  options: ["KMnO4", "Conc. H2SO4", "NaOH", "HCl"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Which alcohol on oxidation gives aldehyde?",
  options: ["Primary alcohol", "Secondary alcohol", "Tertiary alcohol", "Phenol"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Oxidation of secondary alcohol gives:",
  options: ["Aldehyde", "Acid", "Ketone", "Alkene"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Phenol reacts with NaOH to form:",
  options: ["Sodium phenoxide", "Sodium benzoate", "Sodium ethoxide", "Benzene"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Which ether is symmetrical?",
  options: ["CH3–O–C2H5", "C2H5–O–C2H5", "CH3–O–C6H5", "C6H5–O–CH3"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Ethers have lower boiling point than alcohols due to:",
  options: [
    "Lower molecular mass",
    "Lack of hydrogen bonding",
    "Resonance",
    "Steric effect"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Which reaction is used to prepare ethers?",
  options: [
    "Wurtz reaction",
    "Williamson ether synthesis",
    "Kolbe reaction",
    "Reimer–Tiemann reaction"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Williamson ether synthesis proceeds by:",
  options: ["SN1 mechanism", "SN2 mechanism", "Free radical mechanism", "Elimination"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Which ether on heating with HI gives phenol?",
  options: ["Ethyl methyl ether", "Diethyl ether", "Anisole", "Dimethyl ether"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Phenol on Kolbe reaction gives:",
  options: ["Salicylic acid", "Benzoic acid", "Phenyl acetate", "Anisole"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Reimer–Tiemann reaction introduces which group in phenol?",
  options: ["–COOH", "–CHO", "–NO2", "–SO3H"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Which compound is known as carbolic acid?",
  options: ["Methanol", "Ethanol", "Phenol", "Benzoic acid"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Alcohols, Phenols & Ethers",
  q: "Phenol is used mainly in manufacture of:",
  options: ["Soaps", "Plastics", "Fertilizers", "Explosives"],
  ans: 1
},
    
    
    // ===== CHEMISTRY : Coordination Compounds (HARD NEET) =====

{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "A coordination compound consists of:",
  options: [
    "Central metal atom only",
    "Ligands only",
    "Central metal atom and ligands",
    "Ions only"
  ],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "The number of ligands directly bonded to central metal atom is called:",
  options: ["Oxidation number", "Coordination number", "Valency", "Magnetic moment"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which ligand is bidentate?",
  options: ["NH3", "Cl⁻", "en (ethylenediamine)", "H2O"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which ligand is ambidentate?",
  options: ["NH3", "CN⁻", "en", "OH⁻"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which complex shows optical isomerism?",
  options: [
    "[Co(NH3)6]³⁺",
    "[Pt(NH3)2Cl2]",
    "[Co(en)3]³⁺",
    "[Fe(CN)6]⁴⁻"
  ],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "The oxidation state of Fe in [Fe(CN)6]⁴⁻ is:",
  options: ["+2", "+3", "+4", "+6"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which complex is paramagnetic?",
  options: [
    "[Fe(CN)6]⁴⁻",
    "[Co(NH3)6]³⁺",
    "[Ni(CO)4]",
    "[FeF6]³⁻"
  ],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which ligand causes maximum splitting of d-orbitals?",
  options: ["F⁻", "Cl⁻", "NH3", "CN⁻"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "According to CFT, splitting of d-orbitals in octahedral field gives:",
  options: ["2 lower, 3 higher", "3 lower, 2 higher", "Equal splitting", "No splitting"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which orbital is used in dsp² hybridization?",
  options: ["dxy", "dz²", "dx²−y²", "dxz"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which complex has tetrahedral geometry?",
  options: [
    "[Ni(CO)4]",
    "[Pt(NH3)2Cl2]",
    "[Co(NH3)6]³⁺",
    "[Fe(CN)6]³⁻"
  ],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Werner’s theory explains:",
  options: [
    "Bond energies",
    "Isomerism in coordination compounds",
    "Metal extraction",
    "Periodic trends"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "The IUPAC name of [Cr(NH3)6]Cl3 is:",
  options: [
    "Hexaammine chromium(III) chloride",
    "Trichloro hexaammine chromium",
    "Chromium ammine chloride",
    "Hexaammonium chromium"
  ],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which type of isomerism is shown by [Pt(NH3)2Cl2]?",
  options: ["Optical", "Ionization", "Geometrical", "Coordination"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Chelating ligands increase stability due to:",
  options: [
    "Steric hindrance",
    "Chelate effect",
    "Inductive effect",
    "Resonance"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which complex is used in photography?",
  options: [
    "[Ag(CN)2]⁻",
    "[Ag(NH3)2]⁺",
    "[AgCl2]⁻",
    "[Ag(S2O3)2]³⁻"
  ],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which metal ion is present in vitamin B12?",
  options: ["Fe", "Co", "Cu", "Zn"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "EDTA is used in treatment of:",
  options: [
    "Cancer",
    "Lead poisoning",
    "Diabetes",
    "Anemia"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Coordination Compounds",
  q: "Which complex is diamagnetic?",
  options: [
    "[FeF6]³⁻",
    "[NiCl4]²⁻",
    "[Fe(CN)6]⁴⁻",
    "[CoF6]³⁻"
  ],
  ans: 2
},
    
    
    
    // ===== CHEMISTRY : Electrochemistry (HARD NEET) =====

{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Electrochemistry deals with the relationship between:",
  options: [
    "Chemical energy and heat energy",
    "Electrical energy and chemical energy",
    "Mechanical energy and electrical energy",
    "Nuclear energy and chemical energy"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "In a galvanic cell, oxidation occurs at:",
  options: ["Cathode", "Anode", "Salt bridge", "Electrolyte"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "In a galvanic cell, reduction occurs at:",
  options: ["Anode", "Cathode", "Electrolyte", "Salt bridge"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "The standard electrode potential of hydrogen electrode is:",
  options: ["+1.00 V", "0.00 V", "−1.00 V", "+0.76 V"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Which electrode has the highest tendency to lose electrons?",
  options: ["Higher E° value", "Lower E° value", "Zero E° value", "Positive E° only"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "EMF of a galvanic cell is given by:",
  options: ["E°cell = E°anode − E°cathode", "E°cell = E°cathode − E°anode", "E°cell = sum of E°", "E°cell = product of E°"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Which of the following is NOT an electrolytic cell?",
  options: ["Electroplating cell", "Galvanic cell", "Electrolysis of water", "Electrorefining"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Faraday’s first law of electrolysis states that mass deposited is proportional to:",
  options: ["Voltage applied", "Current only", "Charge passed", "Resistance"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "The unit of Faraday constant is:",
  options: ["C mol⁻¹", "V mol⁻¹", "A mol⁻¹", "J mol⁻¹"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "One Faraday is equal to charge of:",
  options: ["1 mole of electrons", "1 coulomb", "1 ampere", "1 volt"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Conductance is the reciprocal of:",
  options: ["Resistance", "Resistivity", "Conductivity", "EMF"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "The SI unit of conductivity is:",
  options: ["ohm", "ohm m", "S m⁻¹", "S"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Molar conductivity of an electrolyte:",
  options: [
    "Decreases with dilution",
    "Increases with dilution",
    "Remains constant",
    "Becomes zero"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Kohlrausch’s law is related to:",
  options: [
    "Strong electrolytes only",
    "Weak electrolytes only",
    "Limiting molar conductivity",
    "Cell potential"
  ],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Which electrolyte shows highest conductivity?",
  options: ["0.1 M NaCl", "0.01 M NaCl", "0.001 M NaCl", "Pure water"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Electrochemical series is arranged in order of:",
  options: [
    "Atomic numbers",
    "Standard electrode potentials",
    "Valency",
    "Electronegativity"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Which metal can displace hydrogen from acids?",
  options: ["Cu", "Ag", "Au", "Zn"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Corrosion of iron is an example of:",
  options: ["Electrolytic process", "Electrochemical process", "Physical process", "Nuclear process"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Rusting of iron is faster in:",
  options: ["Dry air", "Pure water", "Salt water", "Vacuum"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Electrochemistry",
  q: "Which method is used to prevent corrosion?",
  options: ["Galvanization", "Rusting", "Oxidation", "Electrolysis"],
  ans: 0
},
    
    
    // ===== CHEMISTRY : Solutions (HARD NEET) =====

{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "A solution that obeys Raoult’s law over entire range of concentration is called:",
  options: ["Ideal solution", "Non-ideal solution", "Dilute solution", "Concentrated solution"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Which of the following shows positive deviation from Raoult’s law?",
  options: ["Acetone + chloroform", "Ethanol + water", "Benzene + toluene", "Hexane + heptane"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Relative lowering of vapour pressure depends upon:",
  options: ["Nature of solute", "Nature of solvent", "Number of solute particles", "Volume of solution"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Which colligative property is used for determination of molar mass?",
  options: ["Vapour pressure", "Osmotic pressure", "Viscosity", "Surface tension"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Osmotic pressure is maximum when solution is:",
  options: ["Dilute", "Concentrated", "Ideal", "Saturated"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "The unit of osmotic pressure is:",
  options: ["atm", "Pa", "bar", "All of these"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Which solution has highest boiling point?",
  options: ["0.1 m NaCl", "0.1 m glucose", "0.05 m NaCl", "Pure water"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Elevation in boiling point depends upon:",
  options: ["Nature of solute", "Nature of solvent", "Molality", "Molarity"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Depression in freezing point is given by:",
  options: ["ΔTf = Kf m", "ΔTb = Kb m", "π = CRT", "P = X P°"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Van’t Hoff factor is used to explain:",
  options: ["Non-ideality", "Ionization", "Association and dissociation", "Solubility"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "For NaCl in water, van’t Hoff factor is ideally:",
  options: ["1", "2", "3", "0.5"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Which solution is isotonic with blood plasma?",
  options: ["0.9% NaCl", "5% glucose", "Pure water", "0.1 M NaCl"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Hypertonic solution causes RBCs to:",
  options: ["Burst", "Shrink", "Remain same", "Divide"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Molarity changes with temperature because:",
  options: ["Mass changes", "Moles change", "Volume changes", "Density changes only"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Molality is preferred over molarity because it is:",
  options: ["Easy to calculate", "Temperature independent", "More accurate", "Volume based"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Henry’s law is related to solubility of:",
  options: ["Solids in liquids", "Liquids in liquids", "Gases in liquids", "Gases in gases"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Gas solubility increases with:",
  options: ["Increase in temperature", "Decrease in pressure", "Increase in pressure", "Decrease in volume"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Which factor does NOT affect solubility of gases in liquids?",
  options: ["Pressure", "Temperature", "Nature of gas", "Mass of solvent"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Colligative properties depend on:",
  options: ["Nature of solute", "Nature of solvent", "Number of particles", "Chemical composition"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Solutions",
  q: "Which of the following is NOT a colligative property?",
  options: ["Osmotic pressure", "Lowering of vapour pressure", "Elevation of boiling point", "Viscosity"],
  ans: 3
},
    
    
    // ===== CHEMISTRY : Chemical Kinetics (HARD NEET) =====

{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "Chemical kinetics deals with the study of:",
  options: [
    "Energy changes in reactions",
    "Rate of chemical reactions",
    "Equilibrium position",
    "Chemical bonding"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "Rate of reaction is defined as change in:",
  options: [
    "Concentration per unit time",
    "Pressure per unit time",
    "Volume per unit time",
    "Temperature per unit time"
  ],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "The unit of rate constant for a first order reaction is:",
  options: ["mol L⁻¹ s⁻¹", "s⁻¹", "L mol⁻¹ s⁻¹", "mol² L⁻² s⁻¹"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "For a zero order reaction, the rate is independent of:",
  options: ["Concentration", "Temperature", "Catalyst", "Nature of reactant"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "Half-life of a first order reaction depends on:",
  options: ["Initial concentration", "Rate constant", "Temperature only", "Pressure only"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "Half-life of zero order reaction depends on:",
  options: [
    "Initial concentration",
    "Rate constant only",
    "Temperature only",
    "Pressure only"
  ],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "Which plot gives a straight line for a first order reaction?",
  options: [
    "[A] vs t",
    "ln[A] vs t",
    "1/[A] vs t",
    "Rate vs t"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "Arrhenius equation relates rate constant with:",
  options: ["Temperature", "Concentration", "Pressure", "Volume"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "Activation energy is defined as:",
  options: [
    "Energy released during reaction",
    "Minimum energy required for reaction to occur",
    "Total energy of products",
    "Energy of reactants"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "Catalyst increases reaction rate by:",
  options: [
    "Increasing temperature",
    "Decreasing activation energy",
    "Increasing concentration",
    "Changing equilibrium"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "Which factor does NOT affect reaction rate?",
  options: ["Temperature", "Concentration", "Catalyst", "Equilibrium constant"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "For a second order reaction, the unit of rate constant is:",
  options: ["s⁻¹", "mol L⁻¹ s⁻¹", "L mol⁻¹ s⁻¹", "L² mol⁻² s⁻¹"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "The molecularity of a reaction is:",
  options: [
    "Always equal to order",
    "Equal to stoichiometric coefficient",
    "Number of molecules colliding in elementary step",
    "Depends on temperature"
  ],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "Which reaction has constant rate?",
  options: [
    "First order",
    "Second order",
    "Zero order",
    "Third order"
  ],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "Pseudo first order reaction is actually:",
  options: [
    "Zero order",
    "First order",
    "Second order",
    "Third order"
  ],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "Temperature coefficient of a reaction is the factor by which rate increases when temperature is raised by:",
  options: ["1°C", "5°C", "10°C", "20°C"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "For most reactions, the value of temperature coefficient is approximately:",
  options: ["1", "2", "5", "10"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "Which reaction is an example of pseudo first order reaction?",
  options: [
    "Hydrolysis of ester in excess water",
    "Decomposition of NH3",
    "Formation of NH3",
    "Combustion of methane"
  ],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "The slope of Arrhenius plot (ln k vs 1/T) is equal to:",
  options: [
    "−Ea/R",
    "Ea/R",
    "−R/Ea",
    "R/Ea"
  ],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Chemical Kinetics",
  q: "Rate law of a reaction is determined by:",
  options: [
    "Stoichiometry",
    "Experimental data",
    "Thermodynamics",
    "Equilibrium constant"
  ],
  ans: 1
},
    
    
    
    // ===== CHEMISTRY : Surface Chemistry (HARD NEET) =====

{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Surface chemistry deals with phenomena occurring at:",
  options: ["Bulk of substances", "Interface of two phases", "Gaseous phase only", "Liquid phase only"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Adsorption is a process which is:",
  options: ["Bulk phenomenon", "Surface phenomenon", "Chemical reaction", "Irreversible process"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Which type of adsorption involves van der Waals forces?",
  options: ["Chemisorption", "Physisorption", "Ion adsorption", "Selective adsorption"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Physisorption is favored by:",
  options: ["High temperature", "Low temperature", "High activation energy", "Chemical bond formation"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Chemisorption is characterized by:",
  options: ["Low heat of adsorption", "Reversibility", "High specificity", "Multilayer formation"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Which adsorption increases with increase in pressure?",
  options: ["Adsorption of solids", "Adsorption of gases on solids", "Adsorption of liquids", "All adsorptions"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Freundlich adsorption isotherm is valid at:",
  options: ["High pressure only", "Low pressure only", "Moderate pressure", "All pressures"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Which isotherm assumes monolayer adsorption?",
  options: ["Freundlich", "Langmuir", "BET", "Gibbs"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Catalysis occurs due to:",
  options: ["Decrease in temperature", "Increase in activation energy", "Increase in effective collisions", "Change in equilibrium"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Which catalyst is used in Haber process?",
  options: ["Ni", "Fe", "Pt", "V2O5"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Promoters in catalysis are substances which:",
  options: [
    "Increase catalyst amount",
    "Increase catalyst activity",
    "Decrease catalyst activity",
    "React with catalyst"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Which substance acts as poison for catalyst?",
  options: ["K2O", "Mo", "H2S", "Al2O3"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Colloids have particle size range of:",
  options: ["< 1 nm", "1–1000 nm", "> 1000 nm", "Exactly 100 nm"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Which is an example of lyophilic colloid?",
  options: ["Gold sol", "Sulphur sol", "Starch sol", "Ferric hydroxide sol"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Tyndall effect is due to:",
  options: [
    "Reflection of light",
    "Absorption of light",
    "Scattering of light",
    "Refraction of light"
  ],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Brownian motion helps in:",
  options: [
    "Sedimentation",
    "Coagulation",
    "Stability of colloids",
    "Electrophoresis"
  ],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Which method is used to purify colloidal solution?",
  options: ["Coagulation", "Dialysis", "Electrophoresis", "Tyndall effect"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Hardy–Schulze rule is related to:",
  options: [
    "Adsorption",
    "Coagulation of colloids",
    "Catalysis",
    "Electrophoresis"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Gold number is a measure of:",
  options: [
    "Protective power of colloid",
    "Size of particles",
    "Charge on particles",
    "Stability of sol"
  ],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Surface Chemistry",
  q: "Which colloid is used in photography?",
  options: ["Gold sol", "Silver bromide sol", "Starch sol", "Gelatin sol"],
  ans: 1
},
    
    
    // ===== CHEMISTRY : General Principles & Processes of Isolation of Elements (HARD NEET) =====

{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "The process of concentration of ore by hydraulic washing is called:",
  options: ["Calcination", "Roasting", "Leaching", "Gravity separation"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Which method is used for concentration of sulphide ores?",
  options: ["Gravity separation", "Magnetic separation", "Froth flotation", "Leaching"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Roasting of ore is carried out in presence of:",
  options: ["Oxygen", "Nitrogen", "Hydrogen", "Carbon dioxide"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Calcination is carried out in:",
  options: ["Presence of excess air", "Absence or limited air", "Vacuum", "Steam"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Which ore is concentrated by leaching with NaOH?",
  options: ["Bauxite", "Haematite", "Magnetite", "Zinc blende"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Which metal is extracted by carbon reduction?",
  options: ["Aluminium", "Sodium", "Iron", "Magnesium"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Which metal is extracted by electrolysis?",
  options: ["Iron", "Copper", "Aluminium", "Zinc"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "The chief ore of aluminium is:",
  options: ["Cryolite", "Bauxite", "Haematite", "Galena"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Cryolite is added during extraction of aluminium to:",
  options: [
    "Increase conductivity",
    "Lower melting point",
    "Act as catalyst",
    "All of these"
  ],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Which process is used for refining copper?",
  options: ["Zone refining", "Electrolytic refining", "Liquation", "Distillation"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Which impurity is removed by zone refining?",
  options: ["Metals", "Non-metals", "Semiconductors", "Transition metals"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Which metal is purified by Mond process?",
  options: ["Iron", "Copper", "Nickel", "Zinc"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Van Arkel process is used for purification of:",
  options: ["Iron", "Titanium", "Copper", "Aluminium"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Which slag is formed during extraction of iron?",
  options: ["CaSiO3", "FeSiO3", "Al2O3", "MgSiO3"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "In blast furnace, limestone acts as:",
  options: ["Fuel", "Reducing agent", "Flux", "Catalyst"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Which gas is produced during roasting of sulphide ores?",
  options: ["CO2", "SO2", "NO2", "H2S"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "The metal extracted in molten state is:",
  options: ["Copper", "Iron", "Aluminium", "Zinc"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Which process removes volatile impurities?",
  options: ["Liquation", "Distillation", "Zone refining", "Electrolysis"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Which metal cannot be extracted using carbon as reducing agent?",
  options: ["Zn", "Fe", "Pb", "Al"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Isolation of Elements (Metallurgy)",
  q: "Which ore of copper is sulphide ore?",
  options: ["Cuprite", "Malachite", "Chalcopyrite", "Azurite"],
  ans: 2
},
    
    
    // ===== CHEMISTRY : p-Block Elements (Group 15 & 16) – HARD NEET =====

{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Which element of group 15 shows maximum catenation?",
  options: ["Nitrogen", "Phosphorus", "Arsenic", "Bismuth"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Nitrogen does not show catenation due to:",
  options: [
    "Small atomic size",
    "High electronegativity",
    "Weak N–N bond",
    "Absence of d-orbitals"
  ],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Which oxide of nitrogen is neutral?",
  options: ["NO", "NO2", "N2O5", "N2O3"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Which allotrope of phosphorus is most reactive?",
  options: ["White phosphorus", "Red phosphorus", "Black phosphorus", "Violet phosphorus"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "White phosphorus is stored under water because:",
  options: [
    "It is poisonous",
    "It catches fire in air",
    "It reacts with water",
    "It sublimes easily"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Which hydride of group 15 is the strongest reducing agent?",
  options: ["NH3", "PH3", "AsH3", "SbH3"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Basicity of hydrides of group 15 decreases down the group due to:",
  options: [
    "Increase in size",
    "Decrease in bond strength",
    "Decrease in electronegativity",
    "All of these"
  ],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Which oxide of sulphur causes acid rain?",
  options: ["SO2", "SO3", "H2SO4", "H2S"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Which element of group 16 shows maximum electronegativity?",
  options: ["Oxygen", "Sulphur", "Selenium", "Tellurium"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Ozone is prepared in laboratory by:",
  options: [
    "Passing dry air through UV light",
    "Passing oxygen through silent electric discharge",
    "Heating potassium chlorate",
    "Electrolysis of water"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Which allotrope of sulphur is stable at room temperature?",
  options: ["Rhombic sulphur", "Monoclinic sulphur", "Plastic sulphur", "Colloidal sulphur"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Which compound is known as laughing gas?",
  options: ["NO", "NO2", "N2O", "N2O3"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Which oxyacid of sulphur is dibasic?",
  options: ["H2SO4", "H2SO3", "H2S2O7", "All of these"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Which gas is responsible for depletion of ozone layer?",
  options: ["CO2", "SO2", "CFCs", "NO"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Which element shows maximum tendency to form multiple bonds?",
  options: ["Nitrogen", "Phosphorus", "Sulphur", "Arsenic"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "The shape of NH3 molecule is:",
  options: ["Linear", "Trigonal planar", "Trigonal pyramidal", "Tetrahedral"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Which acid is called oil of vitriol?",
  options: ["HNO3", "HCl", "H2SO4", "H3PO4"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Which nitrogen oxide is paramagnetic?",
  options: ["NO", "N2O", "N2O5", "N2O3"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "p-Block Elements (Group 15 & 16)",
  q: "Which compound of phosphorus is used as rat poison?",
  options: ["PH3", "PCl5", "P4O10", "H3PO4"],
  ans: 0
},
    
    // ===== CHEMISTRY : d- & f-Block Elements (HARD NEET) =====

{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Which of the following is a transition metal?",
  options: ["Zn", "Sc", "Cd", "Hg"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Transition metals show variable oxidation states due to:",
  options: [
    "Presence of vacant p-orbitals",
    "Small size",
    "Participation of (n−1)d and ns electrons",
    "High electronegativity"
  ],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Which ion shows maximum paramagnetism?",
  options: ["Fe2+", "Fe3+", "Co2+", "Ni2+"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Which transition metal forms the maximum number of oxides?",
  options: ["Mn", "Fe", "Cr", "V"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "The colour of transition metal ions is due to:",
  options: [
    "Charge transfer",
    "d–d transitions",
    "s–p transitions",
    "Metallic bonding"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Which compound is used as an oxidizing agent in acidic medium?",
  options: ["KMnO4", "K2Cr2O7", "Both A and B", "MnO2"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Which element shows the highest melting point among transition metals?",
  options: ["Fe", "Cr", "W", "Ni"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Which ion is colourless?",
  options: ["Ti4+", "Cu2+", "Cr3+", "Mn2+"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Lanthanoid contraction is due to:",
  options: [
    "Poor shielding of 4f electrons",
    "High nuclear charge",
    "Small atomic size",
    "High electronegativity"
  ],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Which pair shows almost identical properties due to lanthanoid contraction?",
  options: ["Zr & Hf", "Nb & Ta", "Mo & W", "All of these"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Most common oxidation state of lanthanoids is:",
  options: ["+2", "+3", "+4", "+1"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Actinoids show greater range of oxidation states because:",
  options: [
    "5f electrons are more shielded",
    "5f, 6d and 7s electrons have comparable energies",
    "They are radioactive",
    "Large atomic size"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Which actinoid is used as nuclear fuel?",
  options: ["Uranium", "Thorium", "Plutonium", "All of these"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Which ion shows maximum number of unpaired electrons?",
  options: ["Mn2+", "Fe2+", "Co2+", "Ni2+"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Which transition metal does NOT show variable oxidation state?",
  options: ["Sc", "Mn", "Fe", "V"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Which metal is used as a catalyst in Haber process?",
  options: ["Ni", "Pt", "Fe", "Cu"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Which compound of chromium is used in leather tanning?",
  options: ["CrO3", "K2Cr2O7", "Cr2O3", "CrCl3"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Which ion is most stable in aqueous solution?",
  options: ["Cu+", "Ag+", "Au+", "Hg+"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Which transition metal forms amalgams easily?",
  options: ["Cu", "Fe", "Zn", "Ni"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "d- & f-Block Elements",
  q: "Which property decreases across a transition series?",
  options: ["Atomic radius", "Ionization energy", "Density", "Melting point"],
  ans: 0
},
    
    
    // ===== CHEMISTRY : Polymers (HARD NEET) =====

{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Polymers are high molecular mass substances formed by:",
  options: ["Addition of monomers", "Condensation of monomers", "Polymerization of monomers", "Oxidation of monomers"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "The repeating unit in a polymer is derived from:",
  options: ["Catalyst", "Initiator", "Monomer", "Solvent"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Which polymer is formed by addition polymerization?",
  options: ["Nylon-6,6", "Terylene", "Bakelite", "Polythene"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Nylon-6,6 is an example of:",
  options: ["Addition polymer", "Condensation polymer", "Copolyer", "Natural polymer"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Which polymer is biodegradable?",
  options: ["PVC", "Polythene", "PHBV", "Teflon"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Bakelite is a:",
  options: ["Thermoplastic", "Thermosetting polymer", "Elastomer", "Fibre"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Which polymer is used for making non-stick cookware?",
  options: ["PVC", "Teflon", "Nylon", "Polystyrene"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "The monomers used in Buna-S are:",
  options: ["Butadiene + Styrene", "Butadiene + Acrylonitrile", "Isoprene only", "Ethylene + Styrene"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Which polymer is also known as natural rubber?",
  options: ["Polyisoprene", "Polychloroprene", "Buna-N", "Neoprene"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Vulcanization of rubber is done to:",
  options: [
    "Increase elasticity",
    "Increase hardness and strength",
    "Decrease elasticity",
    "Make rubber biodegradable"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Which polymer is used in making bulletproof jackets?",
  options: ["Nylon-6", "Kevlar", "Terylene", "Orlon"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Terylene is a polymer of:",
  options: ["Ethylene glycol + Terephthalic acid", "Caprolactam", "Hexamethylene diamine + Adipic acid", "Styrene"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Which polymer is a copolymer?",
  options: ["Polythene", "PVC", "Buna-N", "Teflon"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Neoprene is obtained by polymerization of:",
  options: ["Isoprene", "Chloroprene", "Butadiene", "Styrene"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Which polymer is used as an insulating material in electrical appliances?",
  options: ["PVC", "Nylon", "Bakelite", "Both A and C"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Which of the following is a natural polymer?",
  options: ["Cellulose", "Nylon", "PVC", "Polystyrene"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Which polymer is used for making ropes and fishing nets?",
  options: ["Nylon-6,6", "Bakelite", "Teflon", "Polystyrene"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "The degree of polymerization refers to:",
  options: [
    "Number of monomers",
    "Number of repeating units",
    "Molecular mass",
    "Chain length only"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Which polymer is used for making disposable cups?",
  options: ["Polystyrene", "PVC", "Nylon", "Bakelite"],
  ans: 0
},
{
  subject: "Chemistry",
  chapter: "Polymers",
  q: "Which polymer is also called polyethylene terephthalate (PET)?",
  options: ["Orlon", "Terylene", "Nylon-6", "PVC"],
  ans: 1
},
    
    // ===== CHEMISTRY : Environmental Chemistry (HARD NEET) =====

{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Which gas is mainly responsible for global warming?",
  options: ["O2", "N2", "CO2", "SO2"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "The major cause of ozone layer depletion is:",
  options: ["CO2", "NO2", "CFCs", "SO3"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Which pollutant is responsible for photochemical smog?",
  options: ["CO", "SO2", "NO2", "CO2"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Acid rain is mainly caused by oxides of:",
  options: ["Carbon and nitrogen", "Sulphur and nitrogen", "Sulphur and carbon", "Nitrogen and hydrogen"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Which acid is a major component of acid rain?",
  options: ["HCl", "HNO3", "H2SO4", "Both HNO3 and H2SO4"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Which gas is known as a greenhouse gas?",
  options: ["Oxygen", "Nitrogen", "Methane", "Hydrogen"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Which pollutant causes blue baby syndrome?",
  options: ["Fluoride", "Nitrate", "Lead", "Mercury"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Which metal causes Minamata disease?",
  options: ["Lead", "Mercury", "Cadmium", "Arsenic"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Which gas causes eye irritation and damages plants in smog?",
  options: ["CO", "O3", "SO2", "NH3"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "PAN (Peroxyacetyl nitrate) is formed in:",
  options: ["Classical smog", "Photochemical smog", "Acid rain", "Greenhouse effect"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Which layer of atmosphere contains ozone layer?",
  options: ["Troposphere", "Stratosphere", "Mesosphere", "Thermosphere"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Which pollutant is released by automobiles?",
  options: ["CO", "SO2", "NO2", "All of these"],
  ans: 3
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "BOD (Biochemical Oxygen Demand) is a measure of:",
  options: [
    "Amount of oxygen required by aquatic life",
    "Organic matter present in water",
    "Purity of drinking water",
    "Amount of dissolved salts"
  ],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Which of the following is a biodegradable pollutant?",
  options: ["Plastics", "DDT", "Sewage", "Polythene"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Which pollutant causes Itai-Itai disease?",
  options: ["Mercury", "Cadmium", "Lead", "Arsenic"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Eutrophication is caused due to excess of:",
  options: ["Heavy metals", "Pesticides", "Nutrients", "Plastics"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Which gas is responsible for ozone formation in photochemical smog?",
  options: ["NO", "NO2", "CO", "SO2"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Which of the following is NOT a primary pollutant?",
  options: ["CO", "SO2", "O3", "NO"],
  ans: 2
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Which method is used to control gaseous pollutants?",
  options: ["Electrostatic precipitator", "Scrubber", "Cyclone separator", "Sedimentation"],
  ans: 1
},
{
  subject: "Chemistry",
  chapter: "Environmental Chemistry",
  q: "Which international agreement is related to protection of ozone layer?",
  options: ["Kyoto Protocol", "Montreal Protocol", "Paris Agreement", "Geneva Convention"],
  ans: 1
},
    
    
    
    // ===== BIOLOGY : Human Reproduction (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "The hormone responsible for ovulation in human females is:",
  options: ["FSH", "LH", "Estrogen", "Progesterone"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Fertilization in humans normally occurs in the:",
  options: ["Ovary", "Uterus", "Cervix", "Ampullary–isthmic junction"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which structure prevents polyspermy in human ovum?",
  options: ["Zona pellucida", "Corona radiata", "Vitelline membrane", "Acrosome"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "The stage of embryo that gets implanted in uterus is:",
  options: ["Morula", "Blastula", "Blastocyst", "Gastrula"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "hCG hormone is secreted by:",
  options: ["Pituitary", "Placenta", "Corpus luteum", "Ovary"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which hormone maintains pregnancy?",
  options: ["Estrogen", "FSH", "LH", "Progesterone"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Placenta is formed by contribution of:",
  options: ["Maternal tissue only", "Fetal tissue only", "Both maternal and fetal tissue", "Amnion only"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Spermatogenesis occurs in:",
  options: ["Epididymis", "Seminiferous tubules", "Vas deferens", "Prostate gland"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which cells provide nutrition to developing sperms?",
  options: ["Leydig cells", "Sertoli cells", "Germ cells", "Epithelial cells"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Testosterone is secreted by:",
  options: ["Sertoli cells", "Leydig cells", "Pituitary gland", "Hypothalamus"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Menstrual cycle is regulated by:",
  options: ["Only FSH", "Only LH", "Only estrogen", "FSH, LH, estrogen and progesterone"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which phase of menstrual cycle is also called proliferative phase?",
  options: ["Menstrual phase", "Follicular phase", "Ovulatory phase", "Luteal phase"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "The average duration of human gestation period is:",
  options: ["180 days", "240 days", "280 days", "300 days"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which hormone is responsible for milk ejection?",
  options: ["Prolactin", "Oxytocin", "Estrogen", "Progesterone"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which hormone stimulates milk production?",
  options: ["Oxytocin", "Estrogen", "Prolactin", "LH"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which contraceptive method prevents implantation?",
  options: ["Condom", "Copper-T", "Vasectomy", "Tubectomy"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Vasectomy involves cutting of:",
  options: ["Urethra", "Seminiferous tubules", "Vas deferens", "Epididymis"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "Which disease is caused by Treponema pallidum?",
  options: ["Gonorrhoea", "Syphilis", "AIDS", "Genital herpes"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "AIDS is caused by:",
  options: ["Bacteria", "Protozoa", "Virus", "Fungus"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Reproduction",
  q: "IVF technique involves fertilization:",
  options: ["Inside uterus", "Inside ovary", "Outside body", "Inside fallopian tube"],
  ans: 2
},
    
    // ===== BIOLOGY : Reproductive Health (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Reproductive health refers to:",
  options: [
    "Absence of disease",
    "Physical well-being only",
    "Complete physical, emotional and social well-being related to reproduction",
    "Only fertility status"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which program was launched in India for reproductive health?",
  options: ["Pulse Polio Programme", "RCH Programme", "NRHM", "ICDS"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which contraceptive method provides protection against STDs?",
  options: ["IUD", "Oral pills", "Condoms", "Tubectomy"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Copper releasing IUDs prevent pregnancy by:",
  options: [
    "Preventing ovulation",
    "Increasing sperm motility",
    "Suppressing sperms and fertilization",
    "Destroying ovum"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Oral contraceptive pills mainly inhibit:",
  options: ["Fertilization", "Ovulation", "Implantation", "Copulation"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Emergency contraceptive pills are effective if taken within:",
  options: ["12 hours", "24 hours", "72 hours", "7 days"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which method is considered permanent contraception in males?",
  options: ["Condom", "Vasectomy", "IUD", "Coitus interruptus"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Medical termination of pregnancy (MTP) is safest during:",
  options: ["First trimester", "Second trimester", "Third trimester", "After birth"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Amniocentesis is used to detect:",
  options: [
    "Sex of fetus",
    "Genetic disorders",
    "Blood group",
    "Gestation period"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which law prohibits sex determination tests in India?",
  options: [
    "MTP Act",
    "PCPNDT Act",
    "RCH Act",
    "NDPS Act"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which STD is caused by a virus?",
  options: ["Gonorrhoea", "Syphilis", "AIDS", "Chlamydia"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which disease causes inflammation of reproductive tract leading to infertility?",
  options: ["Malaria", "Gonorrhoea", "Typhoid", "Tuberculosis"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "ART stands for:",
  options: [
    "Artificial Reproductive Technique",
    "Assisted Reproductive Technology",
    "Advanced Reproductive Treatment",
    "Applied Reproductive Therapy"
  ],
  ans: 1 
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which technique involves transfer of embryo into fallopian tube?",
  options: ["IVF", "GIFT", "IUI", "ZIFT"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Test tube baby technique refers to:",
  options: [
    "GIFT",
    "IVF followed by ET",
    "IUI",
    "Surrogacy"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which hormone is used in birth control pills?",
  options: ["FSH", "LH", "Progesterone", "Testosterone"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which method of contraception is hormone-free?",
  options: ["Oral pills", "Injectables", "Implants", "Copper-T"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which STD is known as bacterial STD?",
  options: ["AIDS", "Genital herpes", "Syphilis", "Hepatitis-B"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Reproductive Health",
  q: "Which is a common symptom of STDs?",
  options: [
    "Fever only",
    "Itching and burning sensation",
    "Hair fall",
    "Joint pain"
  ],
  ans: 1
},
    
    
    
    // ===== BIOLOGY : Principles of Inheritance & Variation (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Mendel conducted his experiments on:",
  options: ["Wheat", "Pea plant", "Maize", "Rice"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "The alternate forms of a gene are called:",
  options: ["Chromatids", "Alleles", "Loci", "Traits"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Mendel’s law of segregation is also known as:",
  options: ["Law of purity of gametes", "Law of dominance", "Law of inheritance", "Law of recombination"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "The phenotypic ratio in a monohybrid cross is:",
  options: ["1:1", "3:1", "9:3:3:1", "1:2:1"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "The genotypic ratio in a monohybrid cross is:",
  options: ["3:1", "1:2:1", "9:3:3:1", "1:1"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "In incomplete dominance, F1 hybrid shows:",
  options: ["Dominant trait", "Recessive trait", "Intermediate trait", "Both traits separately"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "AB blood group is an example of:",
  options: ["Incomplete dominance", "Co-dominance", "Multiple alleles", "Polygenic inheritance"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Haemophilia is a:",
  options: ["Autosomal disorder", "Sex-linked recessive disorder", "Sex-linked dominant disorder", "Chromosomal disorder"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Which disorder is caused due to trisomy of chromosome 21?",
  options: ["Turner syndrome", "Klinefelter syndrome", "Down’s syndrome", "Edward syndrome"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Linkage refers to:",
  options: [
    "Genes present on different chromosomes",
    "Genes present on same chromosome",
    "Alleles separating independently",
    "Random assortment"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Crossing over occurs during:",
  options: ["Prophase I of meiosis", "Metaphase I", "Anaphase I", "Telophase I"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Morgan worked on which organism to study linkage?",
  options: ["Pea plant", "Mouse", "Drosophila", "Bacteria"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Which law explains inheritance of two traits simultaneously?",
  options: [
    "Law of dominance",
    "Law of segregation",
    "Law of independent assortment",
    "Law of variation"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "The phenotypic ratio of dihybrid cross is:",
  options: ["3:1", "1:2:1", "9:3:3:1", "1:1:1:1"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Sickle cell anaemia is caused due to:",
  options: [
    "Deletion mutation",
    "Insertion mutation",
    "Substitution mutation",
    "Frameshift mutation"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Phenylketonuria is a:",
  options: [
    "Chromosomal disorder",
    "Autosomal recessive disorder",
    "Sex-linked disorder",
    "Autosomal dominant disorder"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Multiple alleles are present:",
  options: [
    "In an individual",
    "In a population",
    "Only in males",
    "Only in females"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "The exchange of genetic material between homologous chromosomes is called:",
  options: ["Mutation", "Linkage", "Crossing over", "Transcription"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Principles of Inheritance & Variation",
  q: "Which chromosomal disorder shows XO condition?",
  options: ["Down syndrome", "Turner syndrome", "Klinefelter syndrome", "Cri-du-chat"],
  ans: 1
},
    
    
    // ===== BIOLOGY : Molecular Basis of Inheritance (HARD NEET) =====

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "DNA is a polymer of repeating units called:",

  options: ["Nucleosides", "Nucleotides", "Amino acids", "Fatty acids"],

  ans: 1

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "Which nitrogenous base is NOT present in DNA?",

  options: ["Adenine", "Guanine", "Cytosine", "Uracil"],

  ans: 3

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "In DNA, adenine pairs with thymine by:",

  options: ["One hydrogen bond", "Two hydrogen bonds", "Three hydrogen bonds", "Ionic bond"],

  ans: 1

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "Which scientist proposed the double helix model of DNA?",

  options: ["Watson & Crick", "Meselson & Stahl", "Hershey & Chase", "Chargaff"],

  ans: 0

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "Chargaff’s rule states that:",

  options: [

    "A = T and G = C",

    "A = G and T = C",

    "Purines = Pyrimidines",

    "Both A and C"

  ],

  ans: 3

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "DNA replication is:",

  options: ["Conservative", "Dispersive", "Semi-conservative", "Random"],

  ans: 2

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "Which experiment proved semi-conservative replication?",

  options: [

    "Watson–Crick",

    "Hershey–Chase",

    "Meselson–Stahl",

    "Griffith"

  ],

  ans: 2

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "The enzyme responsible for DNA replication is:",

  options: ["RNA polymerase", "DNA ligase", "DNA polymerase", "Helicase"],

  ans: 2

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "Which enzyme joins Okazaki fragments?",

  options: ["DNA polymerase I", "DNA polymerase III", "DNA ligase", "Primase"],

  ans: 2

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "Transcription occurs in the:",

  options: ["Ribosome", "Cytoplasm", "Nucleus", "Mitochondria"],

  ans: 2

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "Which RNA carries amino acids to ribosome?",

  options: ["mRNA", "rRNA", "tRNA", "snRNA"],

  ans: 2

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "The codon AUG codes for:",

  options: ["Valine", "Methionine", "Tryptophan", "Glycine"],

  ans: 1

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "Which codon is known as start codon?",

  options: ["UAA", "UAG", "UGA", "AUG"],

  ans: 3

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "Which codon does NOT code for any amino acid?",

  options: ["UAA", "UGG", "AUG", "UUU"],

  ans: 0

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "RNA differs from DNA because RNA contains:",

  options: ["Ribose sugar", "Deoxyribose sugar", "Thymine", "Double helix"],

  ans: 0

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "Translation occurs at:",

  options: ["Nucleus", "Ribosome", "Golgi apparatus", "Mitochondria"],

  ans: 1

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "The sequence of bases in DNA decides:",

  options: [

    "Type of RNA",

    "Protein structure",

    "Cell size",

    "Energy production"

  ],

  ans: 1

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "Which mutation changes reading frame?",

  options: ["Substitution", "Insertion", "Deletion", "Both insertion and deletion"],

  ans: 3

},

{

  subject: "Biology",

  chapter: "Molecular Basis of Inheritance",

  q: "Lac operon was discovered by:",

  options: ["Watson & Crick", "Jacob & Monod", "Griffith", "Beadle & Tatum"],

  ans: 1

},
    
    
    // ===== BIOLOGY : Evolution (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Evolution",
  q: "Evolution is defined as:",
  options: [
    "Sudden creation of species",
    "Gradual change in organisms over generations",
    "Change within an individual",
    "Extinction of species"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "The theory of natural selection was proposed by:",
  options: ["Lamarck", "Darwin", "Wallace", "Both Darwin and Wallace"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "According to Darwin, survival of the fittest means:",
  options: [
    "Strongest organisms survive",
    "Most intelligent organisms survive",
    "Best adapted organisms survive",
    "Largest organisms survive"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which scientist proposed inheritance of acquired characters?",
  options: ["Darwin", "Mendel", "Lamarck", "De Vries"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which structure is an example of homologous organs?",
  options: [
    "Wings of bat and bird",
    "Forelimbs of human and whale",
    "Eyes of octopus and human",
    "Wings of butterfly and bird"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Analogous organs indicate:",
  options: [
    "Common ancestry",
    "Divergent evolution",
    "Convergent evolution",
    "Adaptive radiation"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Homologous organs indicate:",
  options: [
    "Convergent evolution",
    "Similar function",
    "Common ancestry",
    "Same habitat"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Industrial melanism is an example of:",
  options: [
    "Natural selection",
    "Mutation",
    "Genetic drift",
    "Speciation"
  ],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which experiment supported chemical evolution?",
  options: [
    "Miller–Urey experiment",
    "Hershey–Chase experiment",
    "Meselson–Stahl experiment",
    "Griffith experiment"
  ],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "The first life forms were:",
  options: [
    "Aerobic",
    "Photosynthetic",
    "Anaerobic",
    "Multicellular"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which gas was absent in primitive atmosphere?",
  options: ["CH4", "NH3", "H2", "O2"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Adaptive radiation was well explained using:",
  options: [
    "Darwin’s finches",
    "Peppered moth",
    "Industrial melanism",
    "Mendel’s peas"
  ],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Hardy–Weinberg principle explains:",
  options: [
    "Speciation",
    "Mutation rate",
    "Genetic equilibrium",
    "Natural selection"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which factor does NOT disturb Hardy–Weinberg equilibrium?",
  options: [
    "Mutation",
    "Gene flow",
    "Random mating",
    "Genetic drift"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "The term ‘species’ refers to:",
  options: [
    "Morphologically similar organisms",
    "Interbreeding population producing fertile offspring",
    "Organisms of same habitat",
    "Genetically identical organisms"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which type of isolation leads to formation of new species?",
  options: [
    "Reproductive isolation",
    "Seasonal isolation",
    "Geographical isolation",
    "All of these"
  ],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which evolutionary force is random in nature?",
  options: [
    "Natural selection",
    "Mutation",
    "Genetic drift",
    "Gene flow"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Modern humans (Homo sapiens) originated in:",
  options: ["Asia", "Europe", "Africa", "Australia"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Evolution",
  q: "Which fossil is known as missing link between reptiles and birds?",
  options: ["Archaeopteryx", "Australopithecus", "Ramapithecus", "Neanderthal"],
  ans: 0
},
    
    
    // ===== BIOLOGY : Human Health & Disease (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Health is defined as a state of complete:",
  options: [
    "Physical well-being only",
    "Mental well-being only",
    "Social well-being only",
    "Physical, mental and social well-being"
  ],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which of the following is a bacterial disease?",
  options: ["AIDS", "Malaria", "Typhoid", "Influenza"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Malaria is caused by:",
  options: ["Bacteria", "Virus", "Protozoa", "Fungus"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "The vector of malaria is:",
  options: ["Culex mosquito", "Aedes mosquito", "Female Anopheles mosquito", "Housefly"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which disease is caused by Plasmodium vivax?",
  options: ["Kala-azar", "Malaria", "Sleeping sickness", "Amoebiasis"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which pathogen causes AIDS?",
  options: ["Bacteria", "Protozoa", "Virus", "Fungus"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "HIV mainly attacks:",
  options: ["RBCs", "Platelets", "Helper T-cells", "B-cells"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which disease is transmitted by Aedes aegypti?",
  options: ["Malaria", "Dengue", "Kala-azar", "Filariasis"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which disease is caused by Entamoeba histolytica?",
  options: ["Typhoid", "Amoebiasis", "Ascariasis", "Giardiasis"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Ascariasis is caused by:",
  options: ["Bacteria", "Virus", "Protozoa", "Helminth"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which antibody is produced first during immune response?",
  options: ["IgA", "IgE", "IgG", "IgM"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Vaccination provides:",
  options: [
    "Passive immunity",
    "Active immunity",
    "Natural immunity",
    "Innate immunity"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which immunity is transferred from mother to child through placenta?",
  options: ["Active immunity", "Innate immunity", "Passive immunity", "Cell-mediated immunity"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Allergic reactions are mediated by:",
  options: ["IgA", "IgD", "IgE", "IgG"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which cells are responsible for cell-mediated immunity?",
  options: ["B-lymphocytes", "Plasma cells", "T-lymphocytes", "RBCs"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Antibiotics are effective against:",
  options: ["Viruses", "Bacteria", "Protozoa", "All pathogens"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which drug is commonly used to treat malaria?",
  options: ["Penicillin", "Quinine", "Streptomycin", "Aspirin"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Cancer is caused due to:",
  options: [
    "Uncontrolled cell division",
    "Cell death",
    "Infection",
    "Immune deficiency"
  ],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Which technique is used for cancer detection?",
  options: ["ELISA", "MRI", "CT scan", "All of these"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Human Health & Disease",
  q: "Drug abuse affects mainly the:",
  options: ["Digestive system", "Respiratory system", "Nervous system", "Excretory system"],
  ans: 2
},
    
    
    // ===== BIOLOGY : Biotechnology – Principles & Processes (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Biotechnology primarily deals with:",
  options: [
    "Use of chemicals in industry",
    "Use of living organisms or their components for products",
    "Study of fossils",
    "Environmental conservation only"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "The enzyme used to cut DNA at specific sites is:",
  options: ["DNA ligase", "Restriction endonuclease", "DNA polymerase", "RNA polymerase"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Restriction enzymes recognize:",
  options: ["Random DNA sequences", "Palindromic sequences", "mRNA", "tRNA"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "The enzyme used to join DNA fragments is:",
  options: ["DNA ligase", "Helicase", "Topoisomerase", "Primase"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Plasmids are commonly used as:",
  options: ["Enzymes", "Vectors", "Hormones", "Antibodies"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Which bacterium is commonly used as a host in recombinant DNA technology?",
  options: ["Salmonella", "Mycobacterium", "Escherichia coli", "Vibrio"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Selectable markers help in:",
  options: [
    "DNA replication",
    "Identifying transformed cells",
    "Protein synthesis",
    "Cell division"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Which gene is used as a selectable marker in E. coli?",
  options: ["Insulin gene", "lacZ", "ampR", "cry gene"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "The technique used to amplify DNA in vitro is:",
  options: ["Gel electrophoresis", "PCR", "Blotting", "Hybridization"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Taq polymerase is isolated from:",
  options: ["E. coli", "Thermus aquaticus", "Bacillus", "Streptococcus"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Which step of PCR involves separation of DNA strands?",
  options: ["Annealing", "Denaturation", "Extension", "Ligation"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Gel electrophoresis separates DNA fragments based on:",
  options: ["Charge", "Shape", "Size", "Sequence"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Ethidium bromide is used in gel electrophoresis to:",
  options: [
    "Cut DNA",
    "Ligate DNA",
    "Stain DNA",
    "Amplify DNA"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Blotting technique used to detect DNA is:",
  options: ["Northern blotting", "Southern blotting", "Western blotting", "Eastern blotting"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Northern blotting is used to detect:",
  options: ["DNA", "RNA", "Protein", "Lipids"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Western blotting is used to detect:",
  options: ["DNA", "RNA", "Protein", "Carbohydrate"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Bioreactors are used for:",
  options: [
    "DNA cutting",
    "Large-scale production of biomolecules",
    "Gene sequencing",
    "Gel separation"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Stirred-tank bioreactors are provided with:",
  options: [
    "UV light",
    "Agitator system",
    "Magnetic field",
    "Vacuum pump"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology – Principles & Processes",
  q: "Downstream processing refers to:",
  options: [
    "DNA replication",
    "Product purification",
    "Transcription",
    "Translation"
  ],
  ans: 1
},
    
    
    // ===== BIOLOGY : Biotechnology & Its Applications (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Recombinant human insulin was first produced using:",
  options: ["Yeast", "E. coli", "Virus", "Plant cells"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Humulin is:",
  options: ["Animal insulin", "Recombinant human insulin", "Plant hormone", "Antibiotic"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Bt cotton is resistant to insects because it produces:",
  options: ["Cry protein", "Interferon", "Insulin", "Antibody"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Cry genes used in Bt crops are derived from:",
  options: ["E. coli", "Agrobacterium tumefaciens", "Bacillus thuringiensis", "Pseudomonas"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "RNA interference (RNAi) is used to:",
  options: [
    "Increase gene expression",
    "Silence specific mRNA",
    "Mutate DNA",
    "Replicate genes"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Golden rice is genetically modified to be rich in:",
  options: ["Vitamin A", "Vitamin B12", "Vitamin C", "Iron"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Which protein is used as a therapeutic agent in cancer treatment?",
  options: ["Interferon", "Insulin", "Trypsin", "Amylase"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Gene therapy aims to:",
  options: [
    "Destroy defective genes",
    "Replace defective genes",
    "Suppress immunity",
    "Produce antibodies"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Which disease was first treated using gene therapy?",
  options: ["SCID", "Cancer", "Diabetes", "Hemophilia"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Transgenic animals are produced mainly for:",
  options: [
    "Food only",
    "Research and pharmaceutical purposes",
    "Entertainment",
    "Decoration"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Which transgenic animal produces human α-1 antitrypsin?",
  options: ["Mouse", "Cow", "Sheep", "Goat"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Edible vaccines are produced using:",
  options: ["Animals", "Plants", "Bacteria", "Viruses"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Which technique is used for DNA fingerprinting?",
  options: ["PCR", "ELISA", "RFLP", "Hybridization"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "DNA fingerprinting is useful in:",
  options: [
    "Disease diagnosis",
    "Forensic science",
    "Paternity testing",
    "All of these"
  ],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Which organization regulates GM crops in India?",
  options: ["ICMR", "GEAC", "CSIR", "DBT"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Biopiracy refers to:",
  options: [
    "Illegal exploitation of bioresources",
    "Gene cloning",
    "Genetic engineering",
    "Bioremediation"
  ],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Biopatent is granted for:",
  options: [
    "Discovery of organism",
    "Invention using biological resources",
    "Natural species",
    "Ecosystems"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Which act in India deals with biodiversity conservation?",
  options: [
    "Wildlife Act",
    "Environment Protection Act",
    "Biodiversity Act, 2002",
    "Forest Act"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biotechnology & Its Applications",
  q: "Which Indian scientist is associated with DNA fingerprinting?",
  options: ["Hargobind Khorana", "Lalji Singh", "M. S. Swaminathan", "C. V. Raman"],
  ans: 1
},
    
    
    // ===== BIOLOGY : Organisms & Populations (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "Ecology is the study of:",
  options: [
    "Cells and tissues",
    "Interaction of organisms with environment",
    "Classification of organisms",
    "Evolution of species"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "The place where an organism lives is called its:",
  options: ["Niche", "Habitat", "Population", "Community"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "The functional role of a species in its ecosystem is called:",
  options: ["Habitat", "Niche", "Biome", "Community"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "Which factor does NOT affect population density?",
  options: ["Birth rate", "Death rate", "Immigration", "Mutation rate"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "The S-shaped population growth curve represents:",
  options: [
    "Exponential growth",
    "Logistic growth",
    "Declining growth",
    "Irregular growth"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "The J-shaped population growth curve is seen when:",
  options: [
    "Resources are limited",
    "Resources are unlimited",
    "Predators are present",
    "Carrying capacity is zero"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "Carrying capacity (K) refers to:",
  options: [
    "Maximum growth rate",
    "Maximum population size environment can sustain",
    "Minimum population size",
    "Average population size"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "Which interaction benefits both species?",
  options: ["Parasitism", "Commensalism", "Mutualism", "Predation"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "An example of commensalism is:",
  options: [
    "Lichen",
    "Cattle egret and grazing cattle",
    "Tapeworm in human",
    "Lion and deer"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "The relationship between tapeworm and human is:",
  options: ["Mutualism", "Commensalism", "Parasitism", "Predation"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "Predator–prey relationship helps in:",
  options: [
    "Eliminating prey completely",
    "Maintaining population balance",
    "Increasing predator population only",
    "Causing extinction"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "Which of the following is a density-dependent factor?",
  options: ["Temperature", "Flood", "Competition", "Earthquake"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "Intraspecific competition occurs between:",
  options: [
    "Different species",
    "Same species",
    "Producers and consumers",
    "Predator and prey"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "Which adaptation helps camel survive in desert?",
  options: [
    "Large ears",
    "Long legs",
    "Concentrated urine",
    "Thin skin"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "The phenomenon where organisms regulate their internal environment is called:",
  options: ["Conformity", "Adaptation", "Homeostasis", "Migration"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "Which organisms are called regulators?",
  options: [
    "Those that migrate",
    "Those that maintain constant internal environment",
    "Those that hibernate",
    "Those that conform to environment"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "Migration in birds is mainly to avoid:",
  options: ["Predators", "Competition", "Unfavourable climate", "Diseases"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "Which population attribute is NOT found in an individual?",
  options: ["Birth rate", "Death rate", "Sex ratio", "Physiology"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Organisms & Populations",
  q: "Population density is measured as:",
  options: [
    "Number of individuals per unit area",
    "Total biomass only",
    "Age structure only",
    "Sex ratio only"
  ],
  ans: 0
},
    
    
    // ===== BIOLOGY : Ecosystem (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "An ecosystem is defined as:",
  options: [
    "A group of organisms",
    "A physical environment",
    "Interaction between biotic and abiotic components",
    "Only plants and animals"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Which of the following is an abiotic component?",
  options: ["Producers", "Consumers", "Decomposers", "Temperature"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Primary producers in an ecosystem are:",
  options: ["Herbivores", "Carnivores", "Green plants", "Decomposers"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Primary consumers are generally:",
  options: ["Carnivores", "Omnivores", "Herbivores", "Decomposers"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Energy flow in an ecosystem is:",
  options: ["Cyclic", "Bidirectional", "Unidirectional", "Random"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Which trophic level has maximum energy?",
  options: ["Producers", "Primary consumers", "Secondary consumers", "Top carnivores"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Ten percent law of energy transfer was proposed by:",
  options: ["Lindeman", "Odum", "Darwin", "Elton"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Which pyramid is always upright?",
  options: [
    "Pyramid of number",
    "Pyramid of biomass",
    "Pyramid of energy",
    "All pyramids"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Which ecosystem has inverted pyramid of biomass?",
  options: ["Forest", "Grassland", "Pond", "Desert"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Which organisms occupy the first trophic level?",
  options: ["Herbivores", "Carnivores", "Producers", "Decomposers"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Detritivores feed on:",
  options: ["Living plants", "Living animals", "Dead organic matter", "Inorganic matter"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Which biogeochemical cycle has no gaseous phase?",
  options: ["Carbon cycle", "Nitrogen cycle", "Phosphorus cycle", "Water cycle"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Which organisms help in mineralization?",
  options: ["Producers", "Consumers", "Decomposers", "Herbivores"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "The process of conversion of nitrates into nitrogen gas is called:",
  options: ["Nitrification", "Nitrogen fixation", "Denitrification", "Ammonification"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Which of the following is a primary productivity?",
  options: [
    "Rate of biomass production by producers",
    "Rate of energy consumption",
    "Rate of decomposition",
    "Rate of respiration"
  ],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Gross primary productivity minus respiration gives:",
  options: ["Net primary productivity", "Secondary productivity", "Biomass", "Standing crop"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Which ecosystem has the highest net primary productivity?",
  options: ["Desert", "Tundra", "Tropical rainforest", "Grassland"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Food chain with more energy loss is:",
  options: ["Grazing food chain", "Detritus food chain", "Aquatic food chain", "Forest food chain"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Which component links biotic and abiotic components?",
  options: ["Producers", "Consumers", "Decomposers", "Herbivores"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Ecosystem",
  q: "Standing crop refers to:",
  options: [
    "Total biomass at a given time",
    "Rate of biomass production",
    "Energy flow",
    "Population size"
  ],
  ans: 0
},
    
    
    // ===== BIOLOGY : Biodiversity & Conservation (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "Biodiversity refers to:",
  options: [
    "Variety of plants only",
    "Variety of animals only",
    "Variety of life forms at all levels",
    "Variety of ecosystems only"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "Which level of biodiversity deals with variation within species?",
  options: ["Species diversity", "Genetic diversity", "Ecosystem diversity", "Community diversity"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "Which country has the highest biodiversity?",
  options: ["India", "Brazil", "China", "Australia"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "India is considered a mega-diversity country because:",
  options: [
    "Large area",
    "High population",
    "High species richness and endemism",
    "Varied climate only"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "Which of the following shows maximum biodiversity?",
  options: ["Temperate forest", "Tundra", "Desert", "Tropical rainforest"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "Species richness means:",
  options: [
    "Number of individuals of a species",
    "Number of species in an area",
    "Evenness of species",
    "Genetic variation"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "Endemic species are those which are:",
  options: [
    "Found everywhere",
    "Found in a particular region only",
    "Introduced species",
    "Extinct species"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "The number of species on Earth is estimated to be about:",
  options: ["1.5 million", "5 million", "7 million", "10 million"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "Which region is known as biodiversity hotspot?",
  options: [
    "Area with high rainfall",
    "Area with high temperature",
    "Area with high endemism and species richness",
    "Area with large population"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "How many biodiversity hotspots are present in India?",
  options: ["2", "3", "4", "5"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "Which of the following is a biodiversity hotspot in India?",
  options: ["Thar desert", "Western Ghats", "Gangetic plains", "Deccan plateau"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "The species–area relationship was given by:",
  options: ["Darwin", "Humboldt", "Wallace", "Elton"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "Loss of biodiversity due to habitat loss is called:",
  options: ["Speciation", "Extinction", "Adaptation", "Evolution"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "The major cause of biodiversity loss is:",
  options: [
    "Over-exploitation",
    "Habitat loss and fragmentation",
    "Alien species invasion",
    "Co-extinction"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "Which term describes mass extinction caused by humans?",
  options: [
    "Natural extinction",
    "Background extinction",
    "Sixth extinction",
    "Adaptive radiation"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "Which conservation method protects species in their natural habitat?",
  options: ["Ex-situ conservation", "In-situ conservation", "Cryopreservation", "Seed bank"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "National parks and wildlife sanctuaries are examples of:",
  options: ["Ex-situ conservation", "In-situ conservation", "Gene banks", "Zoos"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "Botanical gardens and zoos are examples of:",
  options: ["In-situ conservation", "Ex-situ conservation", "Hotspots", "Biosphere reserves"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "Which of the following is an example of ex-situ conservation?",
  options: ["National park", "Wildlife sanctuary", "Seed bank", "Biosphere reserve"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Biodiversity & Conservation",
  q: "The Red Data Book provides information about:",
  options: [
    "Endangered species",
    "Invasive species",
    "Domestic animals",
    "Medicinal plants only"
  ],
  ans: 0
},
    
    
    // ===== BIOLOGY : Environmental Issues (HARD NEET) =====

{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Global warming is mainly caused due to increase in:",
  options: ["Ozone", "Greenhouse gases", "Nitrogen", "Oxygen"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Which gas contributes maximum to greenhouse effect?",
  options: ["Methane", "Nitrous oxide", "Carbon dioxide", "Ozone"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Which protocol aims to reduce emission of greenhouse gases?",
  options: ["Montreal Protocol", "Kyoto Protocol", "Paris Convention", "Stockholm Convention"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Ozone depletion is maximum over:",
  options: ["Equator", "Tropics", "Polar regions", "Temperate regions"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "CFCs destroy ozone by releasing:",
  options: ["Oxygen radicals", "Chlorine radicals", "Nitrogen radicals", "Hydrogen ions"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Which radiation is absorbed by ozone layer?",
  options: ["Infrared", "Visible", "Ultraviolet", "Microwaves"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Acid rain mainly damages:",
  options: ["Aquatic ecosystems", "Forests", "Monuments", "All of these"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Which pollutant causes eutrophication of water bodies?",
  options: ["Nitrates and phosphates", "CO2", "SO2", "Ozone"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Biomagnification refers to:",
  options: [
    "Decrease of pollutant concentration at higher trophic level",
    "Increase of pollutant concentration at higher trophic level",
    "Breakdown of pollutants",
    "Dilution of pollutants"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Which pollutant shows biomagnification?",
  options: ["CO2", "DDT", "SO2", "NH3"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "BOD is an indicator of:",
  options: [
    "Air pollution",
    "Water pollution",
    "Soil pollution",
    "Noise pollution"
  ],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "High BOD value indicates:",
  options: [
    "Clean water",
    "Less organic matter",
    "More organic pollution",
    "Low microbial activity"
  ],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Which pollutant causes smog in cities?",
  options: ["Ozone", "PAN", "NOx", "All of these"],
  ans: 3
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Which disease is caused due to mercury pollution?",
  options: ["Itai-itai", "Minamata", "Blue baby syndrome", "Black lung disease"],
  ans: 1
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Which metal causes Itai-itai disease?",
  options: ["Mercury", "Lead", "Cadmium", "Arsenic"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Noise pollution above which level becomes harmful?",
  options: ["50 dB", "60 dB", "80 dB", "120 dB"],
  ans: 3
},
{  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Solid waste management follows principle of:",
  options: ["Reuse only", "Recycle only", "Reduce, Reuse, Recycle", "Dispose only"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "E-waste contains toxic metals like:",
  options: ["Iron", "Copper", "Lead", "Aluminium"],
  ans: 2
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Which gas causes blue baby syndrome?",
  options: ["Nitrate", "Nitrite", "CO", "SO2"],
  ans: 0
},
{
  subject: "Biology",
  chapter: "Environmental Issues",
  q: "Which renewable source is most eco-friendly?",
  options: ["Coal", "Petroleum", "Solar energy", "Nuclear energy"],
  ans: 2
},
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
       
    
    
    
    {
  // ===== CHEMISTRY =====
      subject: "Chemistry",
    chapter: "Electrochemistry",
    q: "EMF of a cell is maximum when:",
    options: [
      "No current flows",
      "Maximum current flows",
      "Cell is short circuited",
      "Resistance is zero"
    ],
    ans: 0
  },
  {
    subject: "Chemistry",
    chapter: "Coordination Compounds",
    q: "Which shows geometrical isomerism?",
    options: [
      "[Co(NH3)6]3+",
      "[Pt(NH3)2Cl2]",
      "[Ni(CO)4]",
      "[Fe(CN)6]3-"
    ],
    ans: 1
  },
  {
    subject: "Chemistry",
    chapter: "Amines",
    q: "Aniline is a:",
    options: ["Primary amine", "Secondary amine", "Tertiary amine", "Amide"],
    ans: 0
  }

];


















  
  































































window.addEventListener("load", () => {

  setTimeout(() => {

    const splash = document.getElementById("splashScreen");

    splash.style.opacity = "0";

    splash.style.pointerEvents = "none";

    setTimeout(() => {

      splash.style.display = "none";

    }, 400);

  }, 2000); // 2 seconds splash

});












 




let lagatarDin = Number(localStorage.getItem("lagatarDin")) || 0;

let lastActiveDate = localStorage.getItem("lastActiveDate") || null;




function updateLagatarDinOnPositive() {

  const today = getToday();

  if (!lastActiveDate) {

    lagatarDin = 1;

  } else if (lastActiveDate === today) {

    return;

  } else {

    const yesterday = new Date();

    yesterday.setDate(yesterday.getDate() - 1);

    if (lastActiveDate === yesterday.toLocaleDateString()) {

      lagatarDin += 1;

    } else {

      lagatarDin = 1;

    }

  }

  lastActiveDate = today;

  localStorage.setItem("lagatarDin", lagatarDin);

  localStorage.setItem("lastActiveDate", lastActiveDate);

}




const clickSound = new Audio(

 "https://raw.githack.com/sairamom013-spec/study-credit-app./main/pew_pew-dknight556-1379997159.mp3"

);

clickSound.preload = "auto";

const rewardSound = new Audio(

  "https://raw.githubusercontent.com/sairamom013-spec/study-credit-app./main/accha-thik-hai-samjhgya-puneet-superstar.mp3"

);

rewardSound.preload = "auto";

const noteSound = new Audio(

  "https://raw.githubusercontent.com/sairamom013-spec/study-credit-app./main/accha-thik-hai-samjhgya-puneet-superstar.mp3"

);

noteSound.preload = "auto";


function unlockAudio() {

  clickSound.play().then(() => {

    clickSound.pause();

    clickSound.currentTime = 0;

    alert("🔊 Sound enabled!");

  }).catch(e => {

    alert("Sound still blocked 😔");

  });

}

function updateDateTime() {

  const now = new Date();

  const options = {

    weekday: "short",

    day: "2-digit",

    month: "short",

    year: "numeric"

  };

  const date = now.toLocaleDateString("en-IN", options);

  const time = now.toLocaleTimeString("en-IN");

  const el = document.getElementById("dateTime");

  if (el) {

    el.innerText = `📅 ${date}  |  ⏰ ${time}`;

  }

}


updateDateTime();

setInterval(updateDateTime, 1000);


function updateGreeting() {

  const hour = new Date().getHours();

  let message = "";

  if (hour >= 5 && hour < 12) {

    message = "Good Morning Chimni 💓 ! Aaj focus mode ON 💪";

  } else if (hour >= 12 && hour < 17) {

    message = "Good Afternoon Billo!😉 Thoda aur push 🔥";

  } else if (hour >= 17 && hour < 21) {

    message = "Good Evening Chhipkali😏! Finish strong 😎";

  } else {

    message = "Good Night Chiuu💋! Kal phir grind 😏";

  }

  const el = document.getElementById("greeting");

  if (el) {

    el.innerText = message;

  }

}
updateGreeting();





function updateReminderMay() {

  const today = new Date();

  let targetDate = new Date(today.getFullYear(), 4, 3); // Month: 4 = May

  // If May 3 already passed this year, take next year

  if (today > targetDate) {

    targetDate = new Date(today.getFullYear() + 1, 4, 3);

  }

  const diffTime = targetDate - today;

  const daysRemaining = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  const el = document.getElementById("reminderMay");

  if (!el) return;

  if (daysRemaining > 0) {

    el.innerText = `⏳ ${daysRemaining} days remaining for May 3`;

  } else {

    el.innerText = "🎯 Today is the day! May 3 is here 💪";

  }

}




function vibrate(pattern) {

  if (navigator.vibrate) {

    navigator.vibrate(pattern);

  }

}



let credits = localStorage.getItem("credits")

  ? parseFloat(localStorage.getItem("credits"))

  : 0;

let rewardTarget = 26;

updateUI();

function add(value) {
  
  
  if (value > 0) {

  

}
  
  
  
  
  
  
  
  
  function updateUI() {

  // credits text

  document.getElementById("credits").innerText = credits.toFixed(2);

  const progressBar = document.getElementById("progress");

  const rewardText = document.getElementById("rewardText");

  if (!progressBar || !rewardText) return;

  // progress calculation (base = Ice Cream 26)

  let percent = (credits / 26) * 100;

  if (percent > 100) percent = 100;

  if (percent < 0) percent = 0;

  progressBar.style.width = percent + "%";

  // reward text

  if (credits >= 75) {

    rewardText.innerText = "🎧 Air Buds Unlocked!";

  } else if (credits >= 60) {

    rewardText.innerText = "🎁 Surprise Gift Unlocked!";

  } else if (credits >= 47) {

    rewardText.innerText = "🍫 Chocolate Unlocked!";

  } else if (credits >= 26) {

    rewardText.innerText = "🍦 Ice Cream Unlocked!";

  } else {

    rewardText.innerText =

      "🔥 " + (26 - credits).toFixed(2) + " credits to Ice Cream";

  }

}
  
  
 
    // 📳 vibration logic

  if (value > 0) {

    vibrate(70);          // soft vibration for positive

  } else {

    vibrate([100, 60, 100]); // strong vibration for negative

  }
  
  if (typeof showHindiLine === "function") {

  showHindiLine();

}
  
  clickSound.currentTime = 0;

  clickSound.play();

  credits += value;

  if (credits < 0) credits = 0;

  localStorage.setItem("credits", credits);

  updateUI(); // 

}

function updateUI() { 
  
  }

document.getElementById("lagatarDinBadge").innerText =

  "😎 " + lagatarDin;

  
  if (credits === 26) vibrate([80, 40, 80]);        // 🍦 Ice cream

if (credits === 47) vibrate([100, 50, 100]);     // 🍫 Chocolate

if (credits === 60) vibrate([120, 60, 120]);     // 🎁 Gift

if (credits === 75) vibrate([150, 70, 150, 70]); // 🎧 Air Buds

  document.getElementById("credits").innerText = credits.toFixed(2);

  let percent = (credits / rewardTarget) * 100;

  if (percent > 100) percent = 100;

  document.getElementById("progressbar").style.width = percent + "%";

  let rewardText = document.getElementById("rewardText");

  if (credits >= 75) {

    rewardText.innerText = "🎧 Air Buds Unlocked!";

  } else if (credits >= 60) {

    rewardText.innerText = "🎁 Surprise Gift Unlocked!";

  } else if (credits >= 47) {

    rewardText.innerText = "🍫 Chocolate Unlocked!";

  } else if (credits >= 26) {

    rewardText.innerText = "🍦 Ice Cream Unlocked!";

  } else {

    

      "🔥 " + (26 - credits).toFixed(2) + " credits to Ice Cream";
    
    if (credits === 26) showFlirtyPopup(flirtyRewards[26]);

if (credits === 47) showFlirtyPopup(flirtyRewards[47]);

if (credits === 60) showFlirtyPopup(flirtyRewards[60]);

if (credits === 75) showFlirtyPopup(flirtyRewards[75]);
    
    }
    
    
    

  


function toggleDark() {

  document.body.classList.toggle("dark");

}
if (credits === 26) showPopup("🍦 Ice Cream Unlocked!");

if (credits === 47) showPopup("🍫 Chocolate Unlocked!");

if (credits === 60) showPopup("🎁 Surprise Gift Unlocked!");

if (credits === 75) showPopup("🎧 Air Buds Unlocked!");

let streak = localStorage.getItem("streak")

  ? parseInt(localStorage.getItem("streak"))

  : 0;

function addStreak() {

  streak++;

  localStorage.setItem("streak", streak);

  document.getElementById("streak").innerText = streak;

}

let weekData = JSON.parse(localStorage.getItem("weekData")) || [];

function saveToday() {

  let today = new Date().toLocaleDateString();

  weekData.push({ date: today, credits: credits });

  if (weekData.length > 7) weekData.shift();

  localStorage.setItem("weekData", JSON.stringify(weekData));

  showWeeklyStats();

}

function showWeeklyStats() {
  
  vibrate(90);

  let text = "📊 Weekly Progress:\n";

  weekData.forEach(d => {

    text += `${d.date} : ${d.credits} credits\n`;

  });

  alert(text);

}
const hindiLines = [

  "😤 Aaj padhai ho rahi hai, lagta hai reward pakka!",

  "🔥 Arre wah! Aaj toh serious student mode ON hai",

  "😏 Ice cream thodi door hai, par nazar aa rahi hai",

  "📱 Social media band, future ON",
 
  "<News> Bf को हररोज kiisi देने से बढ़ती है उमर 📜",
  
  
  "An job you can do without any education = hand job to ur bf🙈",
  

  "💪 Bas thoda aur, phir chocolate meri!",
  
    "🔥 तुझा discipline पाहून future पण attracted झालंय",

  "😌 आज तू अभ्यासावर पण loyal आहेस, respect h !",

  "💫 Smart decisions are attractive, just saying…",
  
  "wanna be my guitar? I will make beutiful sounds with my fingers 😉",

  "😉 मेहनत अशीच चालू ठेव, vibes heavy आहेत",
  
  "😏 chal  Holi खेळू!!!",
  
  "Blood Vessels: An adult has enough blood vessels to circle the Earth four times 💅",

"Brain Power: The brain can be more active during sleep, and information travels at ~400 km/h 🧠",
  
  " oo बायको जरा चहा बनव की☕!",

  "तुझी चाहूल लागताच, मन बहरून जातं,तुझ्या स्पर्शाने काळीज वेडं होत जातं…तू नसलीस तरी आठवणी ताज्या असतात,तुझ्या प्रेमाशिवाय हे जगच रुक्ष वाटतं💗",

"तुझं हासणं म्हणजे कोवळा सकाळीचा सूर्य😚तुझ्या डोळ्यांत चमकणारा तो गोड चंद्र…👀 तुझ्या मिठीत विसरणारे सगळे दु:ख,तुझ्याशिवाय या जीवनाला नाही रंग…chimne 🤗",

"डोळे मिटले तरी तूच दिसतेस श्वास घेताना तुझा सुगंध भासत सांग तुला कुठे कुठे शोधू मी आता?🥺",

"शेवटच्या क्षणापर्यंत फक्त तुझं नाव असावं,शेवटच्या श्वासापर्यंत तुझ्या मिठीत जगावं…तूच माझं पहिलं आणि शेवटचं प्रेम,आयुष्यभर फक्त तुझं हसणं पहायचंय…💓",
  
  
  
  
  
  

"💫Neurons can fire up to 1,000 times per second it doubles wwhen i am with you",

  "🔥 झट !!! पट !! पटा !! पट !!",
  
  "😁 जा!! जाकर नारियल फोड!!",
  
  "😉 Rolls Royce with some dust",
  
  "😏 breakfast खिलाओ bf koo ",
  
  "😚 माझी चिमनी",
  
   "The brain is capable of storing more information than any computer  so feel it with positive thinking 🖥️",

"Hard things can be turned into soft when you have continuity🍹",
  
  "अह त्वा प्रेम करोमि प्रिये 🥰",

  " in whole  city I only love your kitty 😉",
  
  
  
  
  " Gf daily  protein de krr bf ko kr skti hai strong 💪",
  
  

"The human heart beats about 100,000 times a day Mines only beats for you 💗",

"The average person produces about 1 liter of saliva a day i wanna put some of in your mouth 🤤",


"The human nose can smell more than 1 trillion different scents but your hairs smell are precious 😘",

"The human tongue can taste about 10,000 different flavors but your lips taste is my favourite 👅",

"The human skin is the largest organ in the body, let's stick our largest organs with each other 😉",
  
  " माझ गोंडस बाळ 🤗",

  " 😏 Softies la मनाचा मुजरा",

  "🤭आज phone कमी, तू जास्त interesting वाटतोयस पिल्लु",
  
  "🔥The liver is about the size of a football",

"🔥The liver is the largest internal organ in the body",



  "😉 अभ्यासावर पण एवढं प्रेम? Respect +1",

  "🔥 तुझ्या boyfriend एवढीच हुश्शार आहेस ग तू",

  "😏 तू doctor झाली तरी तूुझं body checkup मीच करणारा h",

  "💋 तू serious असताना अजूनच Sweet दिसतोयस ग",

  " 😁 मेहनत + consistency = dangerous combo",
  

"🔥Alveoli are tiny air sacs where oxygen and carbon dioxide are exchanged",



  "😏 जेवून घे आता चिंमणी !! Dinner आपण करु नंतर"
  

];

function showHindiLine() {

  let line = hindiLines[Math.floor(Math.random() * hindiLines.length)];

  document.getElementById("hindiLine").innerText = line;

}
const flirtyRewards = {

  26: "🍦 Ice cream unlock hui 😏 Treat dene ka plan kab?",

  47: "🍫 Chocolate mil gayi… ab smile bhi free hai 😉",

  60: "🎁 Surprise gift unlocked! Someone’s getting lucky 😌",

  75: "🎧 Air Buds unlocked 😎 Style + brains combo!"

};
function showFlirtyPopup(text) {

  let pop = document.getElementById("flirtyPopup");

  pop.innerText = text;

  pop.style.display = "block";

  setTimeout(() => {

    pop.style.display = "none";

  }, 2500);

}
function getTodayKey() {

  let today = new Date().toLocaleDateString();

  return "note_" + today;

}

function saveNote() {

  let note = document.getElementById("dailyNote").value;

  let key = getTodayKey();

  localStorage.setItem(key, note);

  document.getElementById("noteStatus").innerText =

    "✅ Note saved for today";

  showNotePopup(); // 😏 YE MAGIC LINE
  
  vibrate(60);

}

function loadNote() {

  let key = getTodayKey();

  let savedNote = localStorage.getItem(key);

  if (savedNote) {

    document.getElementById("dailyNote").value = savedNote;

  }

}
loadNote();

const noteFlirtyLines = [

  "😏 Note save ho gaya… consistency is attractive",
 
  "ufff😏",

  "😉 Aaj ka effort safely stored",
  
  "mommy😩",
  "hold it nn",
  "☺️ आज खूप गोड दिसतीये",
  
  
  
  "😊 आनंदा ch क्षण",
  
  "बायको on fire 🔥 ",

  "💫 Likha hua effort kabhi waste nahi jaata",

  "😌 Good job! Aaj ka kaam noted",
  
  "😏  मुलगी शिकली प्रगती झाली",
  " 😉aay haai naughty ",
  
  "  aaah!!😩" ,
  
  " 😚 thike Madam jii",
  
  "aauchh😩",
  
  "🔥 Discipline looks good on you"

];
function showNotePopup() {

  let pop = document.getElementById("notePopup");

  let line =

    noteFlirtyLines[Math.floor(Math.random() * noteFlirtyLines.length)];

  pop.innerText = line;

  pop.style.display = "block";

  setTimeout(() => {

    pop.style.display = "none";

  }, 2000);

}



function updateReminder() {

  // 🔴 Target date: February 10 (Year auto-adjust)

  const today = new Date();

  let targetDate = new Date(today.getFullYear(), 1, 10); // Month: 1 = February

  // If Feb 10 already passed this year, take next year

  if (today > targetDate) {

    targetDate = new Date(today.getFullYear() + 1, 1, 10);

  }

  // Difference in days

  const diffTime = targetDate - today;

  const daysRemaining = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  const el = document.getElementById("reminder");

  if (!el) return;

  if (daysRemaining > 0) {

    el.innerText = `⏳ ${daysRemaining} days remaining for Board exsm`;

  } else {

    el.innerText = "🎯 Today is the day! February 10 is here 💪";

  }

}

updateReminder();       // Feb 10

updateReminderMay();    // May 3

setInterval(() => {

  updateReminder();

  updateReminderMay();

}, 60 * 60 * 1000); // hourly update


updateReminder();

setInterval(updateReminder, 60 * 60 * 1000); // update every hour

const reminderDates = [

  { label: "February 10", month: 1, day: 10 },

  { label: "May 3", month: 4, day: 3 }

];

function updateReminders() {

  const today = new Date();

  const container = document.getElementById("reminders");

  if (!container) return;

  container.innerHTML = ""; // clear old text

  reminderDates.forEach(item => {

    let target = new Date(today.getFullYear(), item.month, item.day);

    if (today > target) {

      target = new Date(today.getFullYear() + 1, item.month, item.day);

    }

    const diffTime = target - today;

    const days = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    const div = document.createElement("div");

    div.style.marginTop = "6px";

    if (days > 0) {

      div.innerText = `⏳ ${days} days remaining for  ${item.label}`;

    } else {

      div.innerText = `🎯 Today is the day! ${item.label} 💪`;

    }

    container.appendChild(div);

  });

}





updateReminder();       // Feb 10

updateReminderMay();    // May 3

setInterval(() => {

  updateReminder();

  updateReminderMay();

}, 60 * 60 * 1000); // hourly updat






function resetCredits() {

  const confirmReset = confirm(

    "⚠️ WARNING!\n\n" +

    "All credits, progress and rewards will be reset.\n" +

    "This action cannot be undone.\n\n" +

    "Are you sure you want to reset🤨?"

  );
  
  lagatarDin = 0;

lastActiveDate = null;

localStorage.removeItem("lagatarDin");

localStorage.removeItem("lastActiveDate");

  if (confirmReset) {

    credits = 0;

    localStorage.removeItem("credits");

    // Reset progress bar & text

    updateUI();

    // Optional vibration

    if (navigator.vibrate) {

      navigator.vibrate([200, 100, 200]);

    }

    alert("✅ Credits reset successfully. Fresh start 💪");

  }

}




  
  
  
  
  
 
  
 
  

function hasTodayNote() {

  const key = "note_" + new Date().toLocaleDateString();

  return localStorage.getItem(key);





if (credits >= 20 && !hasTodayNote()) 

  alert("✍️ Reward ke liye aaj ka note likhna zaroori hai");

}